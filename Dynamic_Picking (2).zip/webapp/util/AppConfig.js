jQuery.sap.declare("com.crave.DynamicPicking.util.AppConfig");
//jQuery.sap.require("cmaintenance.dev.devlogon");

com.crave.DynamicPicking.util.AppConfig = {

	Service: {
		ENTITY1: "FieldConfigSet",
		ENTITY2: "AppConfigSet",
		ENTITY3: "APPPROFILEENTYSet",
	
	},
	Screen:{
	Screen1:"SEARCH",
    Screen2:"LIST",
    Screen3:"LIST - DETAIL",
    Screen4:"ITEM DETAIL - CONFIRM"

	},
	
	loadJsonOffline: function(view, success){
		try{
		sap.OData.applyHttpClient();
		console.log("CALL LOADJSON");
		var oModel  = view.getModel("dm");
	//	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
		var arr = [];
		var len = 6;
		var _Core = sap.ui.getCore();
		_Core.FieldConfigSet = [];
		_Core.AppConfigSet = [];
		_Core.APPPROFILEENTYSet = [];
		
		_Core.ApproverListSet = [];
		//_Core.OrderHistorySet = [];
		//_Core.MobCodeSet = [];
		
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY1 + "?$format=json", null, null, true, function(oResponse) {
			console.log("FieldConfigSet data loaded successfully");
			_Core.FieldConfigSet = oResponse.results;
			arr.push("1");
		com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("1");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("FieldConfigSet Read failed" + error.message);
		});
		
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY2 + "?$format=json", null, null, true, function(oResponse) {
			console.log("AppConfigSet data loaded successfully");
			_Core.AppConfigSet = oResponse.results;
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("AppConfigSet Read failed" + error.message);
		});
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY3 + "?$format=json", null, null, true, function(oResponse) {
			console.log("APPPROFILEENTYSet data loaded successfully");
			_Core.APPPROFILEENTYSet = oResponse.results;
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("APPPROFILEENTYSet Read failed" + error.message);
		});
		
		
		
		/*oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY5 + "?$format=json", null, null, true, function(oResponse) {
			console.log("OperationDetSet data loaded successfully");
			_Core.OperationDetSet = oResponse.results;
			arr.push("5");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("5");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("OperationDetSet Read failed" + error.message);
		});*/
		

		
		
		
	
		
		/*oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY9 + "?$format=json", null, null, true, function(oResponse) {
			console.log("OrderHistorySet data loaded successfully");
			_Core.OrderHistorySet = oResponse.results;
			arr.push("9");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("9");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("OrderHistorySet Read failed" + error.message);
		});*/
		} catch(e){
			view.setBusy(false);
			alert("Exception in loadJsonOffline " + e.message);
		}
	},
	
	loadJsonOnline: function(view, success){
		try{
		//sap.OData.applyHttpClient();
		console.log("CALL loadJsonOnline");
		var oModel  = view.getModel("dm");
	//				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
		var arr = [];
		var len = 6;
		var _Core = sap.ui.getCore();
		_Core.FieldConfigSet = [];
		_Core.AppConfigSet = [];
		//_Core.APPPROFILEENTYSet = [];
	
		//_Core.MobCodeSet = [];
		
		//oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY1 + "?$filter=Profileid eq 'CCALIB'", null, null, true, function(oResponse) {
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY1 + "?$filter=Appid eq 'CWMS30'", null, null, true, function(oResponse) {
			console.log("FieldConfigSet data loaded successfully");
			_Core.FieldConfigSet = oResponse.results;
			arr.push("1");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("1");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("FieldConfigSet Read failed" + error.message);
		});
		
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY2 + "?$filter=Appid eq 'CWMS30'", null, null, true, function(oResponse) {
			console.log("AppConfigSet data loaded successfully");
			_Core.AppConfigSet = oResponse.results;
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("AppConfigSet Read failed" + error.message);
		});
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY3 + "?$filter=AppID eq 'CCALIB'", null, null, true, function(oResponse) {
			console.log("APPPROFILEENTYSet data loaded successfully");
			_Core.APPPROFILEENTYSet = oResponse.results;
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("APPPROFILEENTYSet Read failed" + error.message);
		});
		
		//oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY4 + "?$filter=IsUser eq '"+_Core.USERNAME+"'"/*"?$format=json"*/, null, null, true, function(oResponse) {

		
		/*oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY5 + "?$filter=IsUser eq '"+_Core.USERNAME+"'", null, null, true, function(oResponse) {
			console.log("OperationDetSet data loaded successfully");
			_Core.OperationDetSet = oResponse.results;
			arr.push("5");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("5");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("OperationDetSet Read failed" + error.message);
		});*/
		

		
		/*oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY9 + "?$filter=IsUser eq '"+_Core.USERNAME+"'", null, null, true, function(oResponse) {
			console.log("OrderHistorySet data loaded successfully");
			_Core.OrderHistorySet = oResponse.results;
			arr.push("9");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("9");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("OrderHistorySet Read failed" + error.message);
		});*/
		} catch(e){
			view.setBusy(false);
			alert("Exception in loadJsonOnline " + e.message);
		}
	},
	loadJsonOnline_old: function(view, success){
		try{
		//sap.OData.applyHttpClient();
		console.log("CALL loadJsonOnline");
		var oModel  = view.getModel("dm");
		//				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
		var arr = [];
		var len = 8;
		var _Core = sap.ui.getCore();
		_Core.FieldConfigSet = [];
		_Core.ApplicationConfigSet = [];
		//_Core.APPPROFILEENTYSet = [];
		_Core.OrderDetailSet = [];
		_Core.OperationDetSet = [];
		_Core.MasterInstrumentSet  = [];
		_Core.MeasurementSet = [];
		_Core.ApproverListSet = [];
		_Core.OrderHistorySet = [];
		//_Core.MobCodeSet = [];
		
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY1 + "?$filter=AppID eq 'CWMS30'", null, null, true, function(oResponse) {
			console.log("FieldConfigSet data loaded successfully");
			_Core.FieldConfigSet = oResponse.results;
			arr.push("1");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("1");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("FieldConfigSet Read failed" + error.message);
		});
		
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY2 + "?$filter=AppID eq 'CWMS30'", null, null, true, function(oResponse) {
			console.log("ApplicationConfigSet data loaded successfully");
			_Core.ApplicationConfigSet = oResponse.results;
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("2");
			com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("ApplicationConfigSet Read failed" + error.message);
		});
		oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY3 + "?$filter=AppID eq 'CCALIB'", null, null, true, function(oResponse) {
			console.log("APPPROFILEENTYSet data loaded successfully");
			_Core.APPPROFILEENTYSet = oResponse.results;
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("3");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view,arr,len,success);
			console.log("APPPROFILEENTYSet Read failed" + error.message);
		});
		
	
		
	
		} catch(e){
			view.setBusy(false);
			alert("Exception in loadJsonOnline " + e.message);
		}
	},
	
	loadJsonOfflineOnSync: function(view, success){
		try{
		sap.OData.applyHttpClient();
		console.log("CALL LOADJSON");
		var oModel  = view.getModel("dm");
	//				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
		var arr = [];
		var len = 3;
		var _Core = sap.ui.getCore();
		
		_Core.OrderDetailSet = [];
		//_Core.OperationDetSet = [];
		_Core.MasterInstrumentSet  = [];
		_Core.MeasurementSet = [];
		
	/*	oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY4 + "?$format=json", null, null, true, function(oResponse) {
			console.log("OrderDetailSet data loaded successfully");
			_Core.OrderDetailSet = oResponse.results;
			arr.push("4");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("4");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("OrderDetailSet Read failed" + error.message);
		});
		

		
		oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY6 + "?$format=json", null, null, true, function(oResponse) {
			console.log("MasterInstrumentSet data loaded successfully");
			_Core.MasterInstrumentSet = oResponse.results;
			arr.push("6");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("6");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("MasterInstrumentSet Read failed" + error.message);
		});
		
		oModel.read(cmaintenance.util.CALIButil.AppConfig.Service.ENTITY7 + "?$format=json", null, null, true, function(oResponse) {
			console.log("MeasurementSet data loaded successfully");
			_Core.MeasurementSet = oResponse.results;
			arr.push("7");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
		}, function(error) {
			arr.push("7");
			cmaintenance.util.CALIButil.AppConfig.stopLoading(view,arr,len,success);
			console.log("MeasurementSet Read failed" + error.message);
		});*/
		
		} catch(e){
			view.setBusy(false);
			alert("Exception in loadJsonOffline " + e.message);
		}
	},
	
	stopLoading: function(view, arr, len, success) {
		if (arr.length === len) {
			success();
		}
	},
	
	/* ************************************************** */
	loadJson_Dynamic: function(view, success) {
		try {
			sap.OData.applyHttpClient();
			console.log("CALL LOADJSON");
			var oModel = view.getModel("dm");
					//	var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
			_Core = sap.ui.getCore(),
			 arr = [],
			 len = 2;

			_Core.EntitySet = [];
			_Core.FieldConfigSet = [];
			_Core.APPPROFILEENTYSet = [];
			
			oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY1 + "?$format=json", null, null, true, function(oResponse) {
				console.log("FieldConfigSet data loaded successfully");
				sap.ui.getCore().FieldConfigSet = oResponse.results;
				//alert("FieldConfigSet json = "+oResponse.results.length);
				var entity1 = {
					FieldConfigSet: _Core.FieldConfigSet
				};
				_Core.EntitySet.push(entity1);
				arr.push("1");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view, arr, len, success);
			}, function(error) {
				arr.push("1");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view, arr, len, success);
				console.log("FieldConfigSet Read failed : " + error.message);
			});
			
			oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY2 + "?$format=json", null, null, true, function(oResponse) {
				console.log("APPPROFILEENTYSet data loaded successfully");
				sap.ui.getCore().APPPROFILEENTYSet = oResponse.results;
				//alert("FieldConfigSet json = "+oResponse.results.length);
				var entity1 = {
					APPPROFILEENTYSet: sap.ui.getCore().APPPROFILEENTYSet
				};
				sap.ui.getCore().EntitySet.push(entity1);
				arr.push("2");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view, arr, len, success);
			}, function(error) {
			//	view.setBusy(false);
				arr.push("2");
				com.crave.DynamicPicking.util.AppConfig.stopLoading(view, arr, len, success);
				console.log("APPPROFILEENTYSet Read failed : " + error.message);
			});
		
		} catch (e) {
			view.setBusy(false);
			alert("Exception in AppConfig : " + e.message);
		}
	},

	stopLoading_dynamic: function(view, arr, len, success) {
		/*alert("arr.length : " + arr.length);
		alert("len : " + len);*/
		if (arr.length === 2) {
			//	view.setBusy(false);
			//		alert("call success");
			//	sap.OData.removeHttpClient();
			success();
		}
	},
	
	offlineStoreServiceLoad: function(view, success) {
		try {
			//	sap.OData.applyHttpClient();
	//		view.setBusy(true);
			console.log("CALL offlineStoreServiceLoad");
			var oModel = view.getModel("dm");
				//		var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZCRV_DYN_SERVICE");
			var arr = [];
			var len = 2;
			var FileSetIndex = sap.ui.getCore().Entityname.indexOf("FileSet");
			delete sap.ui.getCore().Entityname[FileSetIndex];
			var NotifCreateSetIndex = sap.ui.getCore().Entityname.indexOf("NotifCreateSet");
			delete sap.ui.getCore().Entityname[NotifCreateSetIndex];
			sap.ui.getCore().Entityname = sap.ui.getCore().Entityname.filter(function(item) {
				return item;
			});
			com.crave.DynamicPicking.util.AppConfig.loadServiceData(view, oModel, 0, function() {
				success();
			});
		//	for(var i = 0; i < sap.ui.getCore().Entityname.length; i++) {
				
				
		//	}
		
		} catch (e) {
			//view.setBusy(false);
			alert("Exception in offlineStoreServiceLoad : " + e.message);
		}
	},
	
	loadServiceData: function(view, oModel, i, success) {
		
		/*var cnt = 0;
	
		
		for(i=0;i<sap.ui.getCore().Entityname.length;i++){
			oModel.read(sap.ui.getCore().Entityname[i] + "?$format=json", null, null, false, function(oResponse) {
			console.log(sap.ui.getCore().Entityname[i] + " data loaded successfully");
			var data = oResponse.results;
			var entityName = sap.ui.getCore().Entityname[i];
			var entity1 = {};
		        entity1[""+entityName+""] = data;

			sap.ui.getCore().EntitySet.push(entity1);
			
			var incr = i + 1;
			//cmaintenance.util.CALIButil.AppConfig.loadServiceData(view, oModel, incr, success);
			if(cnt === sap.ui.getCore().Entityname.length){
			
				success();
			}else{
				cnt++;
			}
		}, function(error) {
			console.log("FieldConfigSet Read failed : " + error.message);
			var incr = i + 1;
			//cmaintenance.util.CALIButil.AppConfig.loadServiceData(view, oModel, incr, success);
			if(cnt === sap.ui.getCore().Entityname.length){
			
				success();
			}else{
				cnt++;
			}
		});
		}*/
		
		if(sap.ui.getCore().Entityname.length === i) {
	//		view.setBusy(false);
			success();
			return;
		}
		
		oModel.read(sap.ui.getCore().Entityname[i] + "?$format=json", null, null, false, function(oResponse) {
			console.log(sap.ui.getCore().Entityname[i] + " data loaded successfully");
			var data = oResponse.results;
			var entityName = sap.ui.getCore().Entityname[i];
			var entity1 = {};
		        entity1[""+entityName+""] = data;

			sap.ui.getCore().EntitySet.push(entity1);
			
			var incr = i + 1;
			com.crave.DynamicPicking.util.AppConfig.loadServiceData(view, oModel, incr, success);
			
		}, function(error) {
			console.log("FieldConfigSet Read failed : " + error.message);
			var incr = i + 1;
			com.crave.DynamicPicking.util.AppConfig.loadServiceData(view, oModel, incr, success);
		});
		
	}
};
jQuery.sap.declare("com.crave.DynamicPicking.js.SignaturePad"), sap.ui.core.Control.extend("com.crave.DynamicPicking.js.SignaturePad", {
    /*metadata: {
      properties: {
        width: {type: 'int', defaultValue: 300},
        height: {type: 'int', defaultValue: 100},
        bgcolor: {type: 'string', defaultValue: '#ffa'},
        lineColor: {type: 'string', defaultValue: '#666'},
        penColor: {type: 'string', defaultValue: '#333'},
        signature: 'string'
      }
    },
    
    renderer: function(oRm, oControl) {
      var bgColor = oControl.getBgcolor();
      var lineColor = oControl.getLineColor();
      var pen = oControl.getPenColor();
      var id = oControl.getId();
      var w = oControl.getWidth();
      var h = oControl.getHeight();
      oRm.write("<div");
      oRm.writeControlData(oControl);
      oRm.write(">");
      oRm.write('<svg xmlns="http://www.w3.org/2000/svg" width="' + w +
                '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">');
      
      oRm.write('<rect id="' + id  + '_r" width="' + w + '" height="' + h + 
                '" fill="' + bgColor  + '"/>');
      
      var hh = h - 20;
      oRm.write('<line x1="0" y1="' + hh  + '" x2="' + w + '" y2="' + hh + 
                '" stroke="' + lineColor + 
                '" stroke-width="1" stroke-dasharray="3" ' + 
                'shape-rendering="crispEdges" pointer-events="none"/>');
      
      oRm.write('<path id="' + id + '_p" stroke="' + pen + '" stroke-width="2" ' +
                'fill="none" pointer-events="none"/>');
      oRm.write('</svg>');
      oRm.write("</div>");
    },
    
    clear: function() {
      this.signaturePath = '';
      var p = document.getElementById(this.getId() + '_p');
      p.setAttribute('d', '');
    },
    
    onAfterRendering: function() {
      var that = this;
      this.signaturePath ='';
      var isDown = false;
      var elm = this.$()[0];
      var r = document.getElementById(this.getId() + '_r');
      var p = document.getElementById(this.getId() + '_p');

      function isTouchEvent(e) {
        return e.type.match(/^touch/);
      }

      function getCoords(e) {
        if (isTouchEvent(e)) {
          return e.targetTouches[0].clientX + ',' +
            e.targetTouches[0].clientY;
        }
        return e.clientX + ',' + e.clientY;
      }

      function down(e) {
        that.signaturePath += 'M' + getCoords(e) + ' ';
        p.setAttribute('d', that.signaturePath);
        isDown = true;
        if (isTouchEvent(e)) {e.preventDefault();}
      }

      function move(e) {
        if (isDown) {
          that.signaturePath += 'L' + getCoords(e) + ' ';
          p.setAttribute('d', that.signaturePath);
        }
        if (isTouchEvent(e)) {e.preventDefault();}
      }

      function up(e) {
        isDown = false; 
        if (isTouchEvent(e)) {e.preventDefault();}
      }

      r.addEventListener('mousedown', down, false);
      r.addEventListener('mousemove', move, false);
      r.addEventListener('mouseup', up, false);
      r.addEventListener('touchstart', down, false);
      r.addEventListener('touchmove', move, false);
      r.addEventListener('touchend', up, false);
      r.addEventListener('mouseout', up, false); 
      
      if (this.getSignature()) {
        console.log('asdasda');
        this.signaturePath = this.getSignature();
        var p = document.getElementById(this.getId() + '_p');
        if (p) {
          p.setAttribute('d', this.signaturePath);
        }
      }
      
      this.setSignature = function(s) {
        this.setProperty('signature', s);
        this.invalidate();
      };
    }*/
    
    
    metadata: {
        properties: {
            width: {
                type: "int",
                defaultValue: 200
            },
            height: {
                type: "int",
                defaultValue: 150
            },
            fillStyle: {
                type: "string",
                defaultValue: "#fff"
            },
            strokeStyle: {
                type: "string",
                defaultValue: "#444"
            },
            lineWidth: {
                type: "float",
                defaultValue: 1.5
            },
            lineCap: {
                type: "string",
                defaultValue: "round"
            },
            penColor: {
                type: "string",
                defaultValue: "#333"
            },
            imageUrl: {
                type: "string",
                defaultValue: ""
            },
            signature: "string"
        }
    },
    renderer: function(e, t) {
        var i = t.getId();
        e.write("<div");
        e.writeControlData(t); 
        e.write(">");
        e.write('<canvas class="roundCorners" id="' + i + '_c" style="position: relative; margin: 0; padding: 0; border: 1px solid #c4caac;" >'); 
        e.write("</canvas>"); 
        e.write("</div>");
    },
    clear: function() {
        me.c.width = me.getWidth();
        me.c.height = me.getHeight();
        var e = me.c.getContext("2d");
        e.fillStyle = this.getFillStyle(); 
        e.strokeStyle = this.getStrokeStyle(); 
        e.lineWidth = this.getLineWidth();
        e.lineCap = this.getLineCap(); e.fillRect(0, 0, me.c.width, me.c.height);
        me._isEmpty = true;
    },
    getSignature: function() {
        return me.c.toDataURL("image/png");
    },
    
    isEmpty: function() {
    	return me._isEmpty;
    },
    onAfterRendering: function() {
    	try{
        function e() {
            me.c.removeEventListener("mousemove", n, !1);
            me.c.removeEventListener("mouseup", a, !1);
            me.c.removeEventListener("touchmove", n, !1);
            me.c.removeEventListener("touchend", a, !1);
            document.body.removeEventListener("mouseup", a, !1);
            document.body.removeEventListener("touchend", a, !1);
        }

        function t(e) {
            var t, i;
            if (e.changedTouches && e.changedTouches[0]) {
                var n = me.c.offsetTop || 0,
                    a = me.c.offsetLeft || 0;
                t = e.changedTouches[0].pageX - a;
                i = e.changedTouches[0].pageY - n;
            } else {
            	e.layerX || 0 == e.layerX ? (t = e.layerX, i = e.layerY) : (e.offsetX || 0 == e.offsetX) && (t = e.offsetX, i = e.offsetY);
            }
            return {
                x: t,
                y: i
            };
        }

        function i(e) {
            e.preventDefault();
            e.stopPropagation();
            me.c.addEventListener("mouseup", a, !1);
            me.c.addEventListener("mousemove", n, !1);
            me.c.addEventListener("touchend", a, !1);
            me.c.addEventListener("touchmove", n, !1);
            document.body.addEventListener("mouseup", a, !1);
            document.body.addEventListener("touchend", a, !1); 
            empty = !1;
            me._isEmpty = false;
            var i = t(e);
            r.beginPath(), 
            d.push("moveStart"), 
            r.moveTo(i.x, i.y), 
            d.push(i.x, i.y), 
            u = i;
        }

        function n(e) {
            e.preventDefault();
            e.stopPropagation();
            var i = t(e),
                n = {
                    x: (u.x + i.x) / 2,
                    y: (u.y + i.y) / 2
                };
            if (l) {
                var a = (c.x + u.x + n.x) / 3,
                    o = (c.y + u.y + n.y) / 3;
                d.push(a, o);
            } else {l = !0;}
            r.quadraticCurveTo(u.x, u.y, n.x, n.y);
            d.push(n.x, n.y);
            r.stroke();
            r.beginPath();
            r.moveTo(n.x, n.y); 
            c = n;
            u = i;
            me._isEmpty = false;
        }

        function a() {
            e();
            s = !1;
            r.stroke();
            d.push("e"); 
            l = !1;
        }
        this._isEmpty = true;
        me = this; 
        me.c = document.getElementById(this.getId() + "_c");
        var r = this.c.getContext("2d");
        if (me.c.width = this.getWidth(), me.c.height = this.getHeight(), r.fillStyle = this.getFillStyle(), r.strokeStyle = this.getStrokeStyle(), r.lineWidth = this.getLineWidth(), r.lineCap = this.getLineCap(), r.fillRect(0, 0, me.c.width, me.c.height), me.getImageUrl()) {
            var o = new Image;
            o.src = me.getImageUrl(), r.drawImage(o, 0, 0)
        }
        var s = !0,
            d = [],
            u = {}, c = {}, l = !1;
        me.c.addEventListener("touchstart", i, !1); 
        me.c.addEventListener("mousedown", i, !1);
    	} catch(e){
    		alert(e.message);
    	}
    }
   
    /*metadata: {
        properties: {
            width: {
                type: "int",
                defaultValue: 200
            },
            height: {
                type: "int",
                defaultValue: 150
            },
            fillStyle: {
                type: "string",
                defaultValue: "#fff"
            },
            strokeStyle: {
                type: "string",
                defaultValue: "#444"
            },
            lineWidth: {
                type: "float",
                defaultValue: 1.5
            },
            lineCap: {
                type: "string",
                defaultValue: "round"
            },
            penColor: {
                type: "string",
                defaultValue: "#333"
            },
            imageUrl: {
                type: "string",
                defaultValue: ""
            },
            signature: "string"
        }
    },
    renderer: function(e, t) {
        var i = t.getId();
        e.write("<div"), 
        e.writeControlData(t), 
        e.write(">"), 
        e.write('<canvas class="roundCorners" id="' + i + '_c" style="position: relative; margin: 0; padding: 0; border: 1px solid #c4caac;" >'), 
        e.write("</canvas>"), 
        e.write("</div>")
    },
    clear: function() {
        me.c.width = me.getWidth(), 
        me.c.height = me.getHeight();
        var e = me.c.getContext("2d");
        e.fillStyle = this.getFillStyle(), 
        e.strokeStyle = this.getStrokeStyle(), 
        e.lineWidth = this.getLineWidth(), 
        e.lineCap = this.getLineCap(), e.fillRect(0, 0, me.c.width, me.c.height);
        me._isEmpty = true;
    },
    getSignature: function() {
        return me.c.toDataURL("image/png");
    },
    
    isEmpty: function() {
    	return me._isEmpty;
    },
    onAfterRendering: function() {
        function e() {
            me.c.removeEventListener("mousemove", n, !1), 
            me.c.removeEventListener("mouseup", a, !1), 
            me.c.removeEventListener("touchmove", n, !1), 
            me.c.removeEventListener("touchend", a, !1), 
            document.body.removeEventListener("mouseup", a, !1), 
            document.body.removeEventListener("touchend", a, !1)
        }

        function t(e) {
            var t, i;
            if (e.changedTouches && e.changedTouches[0]) {
                var n = me.c.offsetTop || 0,
                    a = me.c.offsetLeft || 0;
                t = e.changedTouches[0].pageX - a, 
                i = e.changedTouches[0].pageY - n
            } else 
            	e.layerX || 0 == e.layerX ? (t = e.layerX, i = e.layerY) : (e.offsetX || 0 == e.offsetX) && (t = e.offsetX, i = e.offsetY);
            return {
                x: t,
                y: i
            }
        }

        function i(e) {
            e.preventDefault(), 
            e.stopPropagation(), 
            me.c.addEventListener("mouseup", a, !1), 
            me.c.addEventListener("mousemove", n, !1), 
            me.c.addEventListener("touchend", a, !1), 
            me.c.addEventListener("touchmove", n, !1), 
            document.body.addEventListener("mouseup", a, !1), 
            document.body.addEventListener("touchend", a, !1), 
            empty = !1;
            me._isEmpty = false;
            var i = t(e);
            r.beginPath(), 
            d.push("moveStart"), 
            r.moveTo(i.x, i.y), 
            d.push(i.x, i.y), 
            u = i
        }

        function n(e) {
            e.preventDefault(), 
            e.stopPropagation();
            var i = t(e),
                n = {
                    x: (u.x + i.x) / 2,
                    y: (u.y + i.y) / 2
                };
            if (l) {
                var a = (c.x + u.x + n.x) / 3,
                    o = (c.y + u.y + n.y) / 3;
                d.push(a, o)
            } else l = !0;
            r.quadraticCurveTo(u.x, u.y, n.x, n.y), 
            d.push(n.x, n.y), 
            r.stroke(), 
            r.beginPath(), 
            r.moveTo(n.x, n.y), 
            c = n, 
            u = i
            me._isEmpty = false;
        }

        function a() {
            e(), 
            s = !1, 
            r.stroke(), 
            d.push("e"), 
            l = !1
        }
        this._isEmpty = true;
        me = this, 
        me.c = document.getElementById(this.getId() + "_c");
        var r = this.c.getContext("2d");
        if (me.c.width = this.getWidth(), me.c.height = this.getHeight(), r.fillStyle = this.getFillStyle(), r.strokeStyle = this.getStrokeStyle(), r.lineWidth = this.getLineWidth(), r.lineCap = this.getLineCap(), r.fillRect(0, 0, me.c.width, me.c.height), me.getImageUrl()) {
            var o = new Image;
            o.src = me.getImageUrl(), r.drawImage(o, 0, 0)
        }
        var s = !0,
            d = [],
            u = {}, c = {}, l = !1;
        me.c.addEventListener("touchstart", i, !1), 
        me.c.addEventListener("mousedown", i, !1)
    }*/
    
    
    
    
    
    
});
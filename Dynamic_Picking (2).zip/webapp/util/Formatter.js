jQuery.sap.declare("com.crave.DynamicPicking.util.Formatter");

com.crave.DynamicPicking.util.Formatter = {
	/**
	 * Upper the first character of giving string
	 * param{String} sStr input string
	 * @returns {String}} the input string with the first uppercase character
	 */
	uppercaseFirstChar: function(sStr) {
		return sStr.charAt(0).toUpperCase() + sStr.slice(1);
	},
	setVisible: function(value) {
		if (value === true) {
			return true;
		} else {
			return false;
		}
	},
	setVisibleBtch: function(value) {
		if (value === "B") {
			return true;
		} else {
			return false;
		}
	},
	setVisibleSerial: function(value) {
		if (value === "S") {
			return true;
		} else {
			return false;
		}
	},
	batchValue: function(value, valBatch) {
		var inpId = this.getId();
		if (value === true) {
			if (valBatch) {
				sap.ui.getCore().byId(inpId).setEditable(false);
				return valBatch;
			} else {
				return valBatch;
			}
		}
	},
	batchVisible: function(value) {
		if (value === "") {
			return false;
		} else {
			return true;
		}
	},
	DateFormatter: function(Date) {
		try {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MM/dd/yyyy"
			}); //Returns a DateFormat instance for date and time
			if (Date != null) {
				Date.getTimezoneOffset();
				Date.setMinutes(Date.getMinutes() + Date.getTimezoneOffset());
				return oDateFormat.format(Date);
			} else {
				return "";
			}
		} catch (e) {
			return "";
		}
	},
	noDecimals: function(value) {
		return value.substring(0, value.indexOf('.'));
	},
	toDateFormatLab: function(date) {
		try {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "MM/dd/yyyy"
			}); //Returns a DateFormat instance for date and time

			if (date != null) {
				return oDateFormat.format(date);
			} else {
				return "";
			}
		} catch (e) {
			return "";
		}
	}

	/*
	discontinuedStatusState : function(sDate) {
		return sDate ? "Error" : "None";
	},

	discontinuedStatusValue : function(sDate) {
		return sDate ? "Discontinued" : "";
	},

	currencyValue : function (value) {
		return parseFloat(value).toFixed(2);
	}
	*/
};
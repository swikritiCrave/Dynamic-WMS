sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"com/crave/DynamicPicking/model/models"
], function (UIComponent, ODataModel, JSONModel, Device, models) {
	"use strict";

	return UIComponent.extend("com.crave.DynamicPicking.Component", {

		metadata: {
			manifest: "json"
		},
			syncStore : function(){
				this.devLogon.flushAppOfflineStore();          
			},
			
			refreshStore : function(){
				this.devLogon.refreshAppOfflineStore(); 
			},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			
				var _Core = sap.ui.getCore();
				_Core.device = false;
			
			sap.ui.getCore().dm = "/sap/opu/odata/SAP/ZCRV_DYN_SERVICE";
				sap.ui.getCore().cm = "/WMS900/sap/opu/odata/CRVWM/WMS_SRV";
			
			
			
				sap.ui.getCore().CONFIG_REFRESH = {};
			
				var param = {
					"json": true,
					loadMetadataAsync: true
				};
				var appMeta = this.getMetadata().getManifestEntry("sap.app");
				var sServiceUrl1 = appMeta.dataSources.mainService.uri;
				var sServiceUrl2 = appMeta.dataSources.WMS.uri;
			var oModel = new ODataModel(sServiceUrl1, param);
				oModel.setDefaultBindingMode("TwoWay");
				this.setModel(oModel);
				////////////////////
				oModel = new ODataModel(sServiceUrl1, param);
				oModel.setDefaultBindingMode("TwoWay");
				this.setModel(oModel, "dm");
				
				oModel = new ODataModel(sServiceUrl2, param);
				oModel.setDefaultBindingMode("TwoWay");
				this.setModel(oModel, "cm");
			
			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});
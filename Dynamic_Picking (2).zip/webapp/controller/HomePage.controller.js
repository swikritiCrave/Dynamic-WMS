sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/m/MessageBox"
], function (Controller, JSONModel, Dialog, MessageBox) {
	"use strict";
	jQuery.sap.require("com.crave.DynamicPicking.util.AppConfig");
	return Controller.extend("com.crave.DynamicPicking.controller.HomePage", {

		onInit: function () {
			sap.ui.getCore().homeThis = this;

			sap.ui.getCore().Count = 0;
			sap.ui.getCore().Listdata = [];
			sap.ui.getCore().step1 = [];
			sap.ui.getCore().step2 = [];
			sap.ui.getCore().step3 = [];
			sap.ui.getCore().step4 = [];
			sap.ui.getCore().step5 = [];
			sap.ui.getCore().step6 = [];
			sap.ui.getCore().step7 = [];
			sap.ui.getCore().step8 = [];
			sap.ui.getCore().busy_dialogIBPS = new sap.m.BusyDialog({
				text: 'Please wait...'
			});

			//	myInputField._getValueHelpIcon().setSrc("sap-icon://bar-code");
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.oEvent = sap.ui.getCore().getEventBus();
			//	this.LoadEntitySet();
			//	this.LoadFieldConfigSet();
			//	this.initialize();
			//		this.setNumbersToIconTabFilter();
			//	this.masterListBinding();

		},
		onBeforeRendering: function () {
			var that = this;
			//		that.initialize();
			// var id="TAB73"
			//	sap.ui.getCore().ctabitemid="TAB73";
			//	that.detailBindFooterButton(sap.ui.getCore().ctabitemid);
			//	that.BindHeaderData();
			//	sap.ui.core.BusyIndicator.show();
			//	that.detailBindFooterButton(sap.ui.getCore().ctabitemid);

		},

		initialize: function () {
			var that = sap.ui.getCore().homeThis;
			var _SelectedKey = null;

			that._PAGE = that.getView().byId("homePage");

			that.columnsContext = [];

			//Add Tab

			that._BAR = that.getView().byId("tabContainer");
			var data = sap.ui.getCore().positionData;
			var icondata = "";
			//	that.data[i].SubItmId === 'TILE04' //sap.ui.getCore().SubItmId
			if (data.length > 0 && sap.ui.getCore().Count < data.length) {
				for (var i = 0; i < data.length; i++) {
					//Add Tab Content

					if (data[i].icon === "") {
						icondata = "sap-icon://edit";
					} else {
						icondata = data[i].icon;
					}
					that._BAR.addItem(new sap.m.IconTabFilter({
						id: "STEP" + data[i].UiPosition,
						text: data[i].FieldLabel,
						key: data[i].UiPosition,
						icon: icondata,
						enabled: false
					})).addStyleClass("").addStyleClass("");

					sap.ui.getCore().Count++;
				}
				if (!_SelectedKey) {
					_SelectedKey = "1";
					sap.ui.getCore().byId("STEP1").setEnabled(true);
				}
				sap.ui.getCore().x = that._BAR.getItems();
				sap.ui.getCore().SelectedKey = "1";
				sap.ui.getCore().ctabitemid = sap.ui.getCore().positionData[0].ItmId;
				that.addTabFilterAndContent(0, sap.ui.getCore().positionData, function () {});
				that.detailBindFooterButton(sap.ui.getCore().ctabitemid);
			}
		},

		detailBindFooterButton: function (itemId) {
			try {
				var view = this.getView();

				var btnData = [];
				var positions = [];
				var totalBtn = sap.ui.getCore().FieldConfigSet1.filter(function (item) {
					if (item.InputType.match("BTN") && item.SubItmId.match(sap.ui.getCore().ctabitemid) && item.Active.match(
							"X")) {
						positions.push(item.UiPosition);
						//if (item.UiPosition === "1") {
						//	view.byId("button1").setVisible(true);

						/*	view.byId("button1").setText(item.FieldLabel);
							if(item.icon !== ""){
							    view.byId("button1").setIcon("sap-icon://"+item.icon);
							}*/
						//	} 
						return item;
					}
				});

				if (totalBtn !== undefined && totalBtn.length > 0) {
					this.addButtons(1, positions, totalBtn, btnData, view, function () {});
					//	}
				} else {
					var toolbar = view.byId("stepsfooter");
					toolbar.destroyContent();
				}
			} catch (e) {
				alert("detailBindFooterButton Exception : " + e.message);
			}
		},

		addButtons: function (i, j, totalBtn, btnData, view, success) {
			var that = this;
			try {
				if (totalBtn.length + 1 === i) {

					var toolbar = view.byId("stepsfooter");
					toolbar.destroyContent();
					toolbar.addContent(new sap.m.Bar({
						design: sap.m.BarDesign.Footer,
						contentLeft: [btnData],
						contentMiddle: [],
						contentRight: []

					}).addStyleClass("footerbckground").addStyleClass("footercontainer"));
					return success();
				}
				var icon = "";
				j.sort();
				totalBtn.filter(function (item) {
					if (item.UiPosition === "" + j[totalBtn.length - i] + "") {
						if (item.icon !== "") {
							icon = "sap-icon://" + item.icon;
						}
						if (item.FieldLabel === "Search") {
							var btnlabelaccept = "Search";

						} else if (item.FieldLabel === "Confirm") {
							var btnlabelaccept = "Search";

						} else {
							var btnlabelaccept = item.FieldLabel;
						}

						btnData.push(new sap.m.Button({
							//	text: item.FieldLabel,
							text: item.FieldLabel,
							icon: icon,
							width: "100%",
							press: view.getController().btnAction
						}).addStyleClass("btncss").setLayoutData(new sap.m.ToolbarLayoutData({
							shrinkable: true
						})))

					}
				});
				i++;
				this.addButtons(i, j, totalBtn, btnData, view, success);
			} catch (e) {
				alert("addButtons Exception: " + e.message);
			}
		},

		btnAction: function (oEvent) {
			try {
				var that = this;
				var btntxt = oEvent.getSource().mProperties.text;

				sap.ui.getCore().homeThis.onSearchID();

			} catch (e) {
				alert("btnAction Exception: " + e.message);
			}
		},

		BindHeaderData: function (position) {
			try {

				var view = this.getView();
				var detailData = [];
				var headerlistData = [];
				var headerPositions = [];
				var FieldName;
				sap.ui.getCore().FieldConfigSet1.filter(function (item) {
					if (item.Profileid === sap.ui.getCore().ProfileID) {
						if (item.SubItmId.match(data[i].ItmId) && item.ItemType.match("HEAD") && item.Active.match("X")) {
							if (headerlistData.indexOf(item.FieldName) === -1 && item.UiPosition !== undefined) {
								var getListData = [{
									EntyId: item.EntyId,
									FieldLabel: item.FieldLabel,
									UiPosition: item.UiPosition,
									FieldName: item.FieldName,
									InputType: item.InputType
								}];
								/*if(item.ckey !== "" && item.ckey !== undefined){
									FieldName = item.FieldName;
								}*/
								headerPositions.push(item.UiPosition);
								headerlistData.push(getListData[0]);
							}
							//	return item;
						}
					}
				});
				sap.ui.getCore().headerData = [];
				if (headerlistData.length !== 0) {
					this.addHeaderPositionData(1, headerPositions.sort(), headerlistData, function () {});
				}

				sap.ui.getCore().headertemplate = new sap.m.Panel({
					id: "pnlheaderTAB_" + sap.ui.getCore().SelectedKey,
					title: new sap.ui.core.Title({
						text: ""
					})

				}).addStyleClass("hdr_panel");

				var pnl1 = view.byId("pnlheaderTAB_" + position);

				for (var i = 0; i < (sap.ui.getCore().headerData).length; i++) {
					var lbl = new sap.m.Label({
						design: sap.m.LabelDesign.Bold,
						text: sap.ui.getCore().headerData[i].FieldLabel,
						width: "50%"
					}).addStyleClass("hdr_text");
					var txt = new sap.m.Label({
						design: sap.m.LabelDesign.Bold,
						text: "",
						width: "50%",
						id: sap.ui.getCore().headerData[i].FieldName + "_" + position
					}).addStyleClass("hdr_text");

					pnl1.addContent(lbl);
					pnl1.addContent(txt);

				}

				//	this.addTabFilterAndContent(0, sap.ui.getCore().positionData, function() {});

			}

			//	sap.ui.getCore().detailBack = true;
			catch (e) {
				console.log("bindHeaderData Exception: " + e.message);
			}
			return pnl1;
		},

		addHeaderPositionData: function (i, positions, data, success) {
			//	swikriti changes 05-09
			if (data.length + 1 === i) {
				return success();
			}

			data.filter(function (item) {
				if (item.UiPosition === "" + positions[i - 1] + "") {
					return sap.ui.getCore().headerData.push(item);
				}
			});
			//	swikriti changes 05-09
			i++;
			//
			this.addHeaderPositionData(i, positions, data, success);
		},

		onRouteMatched: function (oEvent) {
			//	var that=this;
			//	that.initialize();
			var that = this;
			that.LoadEntitySet();
			that.LoadFieldConfigSet();
			//	this.initialize();
			that.initialize();
			that.setNumbersToIconTabFilter();

		},
		LoadEntitySet: function () {
			this.getOwnerComponent().getModel("dm").read("/APPPROFILEENTYSet", {
				success: function (oResponse) {

					sap.ui.getCore().APPPROFILEENTYSet = oResponse.results;
					console.log("apconfigSet1 data loaded successfully");
				},
				error: function (err) {
					console.log(err);
					//	eb(err);
				}
			});

		},
		LoadFieldConfigSet: function () {
			var that = this;
			var view = sap.ui.getCore().homeThis.getView();
			//	var oModel  = view.getModel();
			var oModel = this.getOwnerComponent().getModel("dm");
			sap.ui.getCore().ProfileID = "CWMS30";
			oModel.read(com.crave.DynamicPicking.util.AppConfig.Service.ENTITY1 + "?$filter=Profileid%20eq%20%27" + sap.ui.getCore().ProfileID +
				"%27%20&$format=json", null, null, false,
				function (oResponse) {

					sap.ui.getCore().FieldConfigSet1 = oResponse.results;
					console.log("FieldConfigSet1 data loaded successfully");
					var entity12 = {
						FieldConfigSet: sap.ui.getCore().FieldConfigSet1
					};
					//	sap.ui.getCore().EntitySet1.push(entity12);
					var tabData = [];
					var positions = [];
					//	var newelement={};
					tabData = sap.ui.getCore().FieldConfigSet1.filter(function (item) {

						if (item.SubItmId === "GR00" && item.ItemType === "STEP" && item.Active.match("X")) {
							positions.push(item.UiPosition);
							if (item.UiPosition === "1") {
								item["screen"] = "SEARCH";
								//	item.add(newelement);
							}
							if (item.UiPosition === "2") {
								item["screen"] = "LIST";
								//	item.add(newelement);
							}
							if (item.UiPosition === "3") {
								item["screen"] = "LIST - DETAIL";
								//	item.add(newelement);
							}
							if (item.UiPosition === "4") {
								item["screen"] = "ITEM DETAIL - CONFIRM";
								//	item.add(newelement);
							}

							return item;

						}
					});
					sap.ui.getCore().positionData = [];
					that.addPositionData(1, positions.sort(), tabData, function () {});

				},
				function (error) {

					console.log("FieldConfigSet Read failed : " + error.message);
				});

		},

		showAlert: function (msg) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.alert(
				msg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},

		onSearchID: function () {
			//	var view = this.getView();
			var that = this;
			sap.ui.getCore().busy_dialogIBPS.open();
			sap.ui.getCore().homeThis.setNumbersToIconTabFilter();
			var view = sap.ui.getCore().homeThis.getView();
			var oModel = view.getModel();
			var tabContent;
			var model = new sap.ui.model.odata.ODataModel("/WMS900/sap/opu/odata/CRVWM/WMS_SRV");
			sap.ui.getCore().model1 = new sap.ui.model.odata.ODataModel("/WMS900/sap/opu/odata/CRVWM/WMS_SRV");
			sap.ui.getCore().GlobalM = sap.ui.getCore().homeThis.getView().getModel();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});

			sap.ui.getCore().search_URL_ID = [];
			sap.ui.getCore().search_URL1 = "";
			sap.ui.getCore().search_URL = "/GRSearchSet?$filter=";

			sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey).setVisible(false);
			sap.ui.getCore().SerachParams = [];
			sap.ui.getCore().FieldConfigSet1.filter(function (item) {
				if (item.ItemType === "SER" &&
					item.SubItmId === sap.ui.getCore().ctabitemid && item.Active.match("X") && item.InputType !== "BTN") {
					var newElement = {};
					if (item.InputType === "DD") {
						var id = sap.ui.getCore().byId("dd_" + (item.FieldName) + "_" + sap.ui.getCore().SelectedKey);
						var value = id.getSelectedKey();
						newElement[(item.FieldName)] = value;
						sap.ui.getCore().SerachParams.push(newElement);
					} else if (item.InputType === "QR") {
						id = sap.ui.getCore().byId("QRCODE_" + (item.FieldName) + "_" + sap.ui.getCore().SelectedKey);
						value = id.getValue();
						newElement[(item.FieldName)] = value;
						sap.ui.getCore().SerachParams.push(newElement);
					} else if (item.InputType === "ED") {
						id = sap.ui.getCore().byId("inp_" + (item.FieldName) + "_" + sap.ui.getCore().SelectedKey);
						value = id.getValue();
						newElement[(item.FieldName)] = value;
						sap.ui.getCore().SerachParams.push(newElement);
					} else if (item.InputType === "DT") {
						id = sap.ui.getCore().byId("dp_" + (item.FieldName) + "_" + sap.ui.getCore().SelectedKey);
						value = id.getDateValue();
						value = value !== null ? oDateFormat.format(new Date(value)) : "0000-00-00";

						newElement[(item.FieldName)] = value;
						sap.ui.getCore().SerachParams.push(newElement);
					}
				}
			});
			sap.ui.getCore().movement_type = "101";
			sap.ui.getCore().search_URL = "/GRSearchSet?$filter=";
			sap.ui.getCore().SerachParams.filter(function (item) {
				for (var key in item) {
					if (item.hasOwnProperty(key)) {

						if (key === "PoNumber" && item[key] !== "") {
							sap.ui.getCore().search_URL = "/GRSearchSet?$filter=" + key + "%20eq%20%27" + item[key] + "%27";
							sap.ui.getCore().search_URL1 = "/GRSearchSet?$filter=" + key + "%20eq%20%27" + item[key] + "%27";
						} else {
							if (key === "CreatedFrom") {
								(sap.ui.getCore().search_URL) += (key + "%20ge%20datetime%27" + item[key] + "T00:00:00%27%20and%20");
							} else if (key === "CreatedTo") {
								(sap.ui.getCore().search_URL) += (key + "%20le%20datetime%27" + item[key] + "T00:00:00%27%20and%20");
							} else {
								(sap.ui.getCore().search_URL) += key + "%20eq%20%27" + item[key] + "%27%20and%20";
							}
						}
					}
				}
			});

			//    );

			if (sap.ui.getCore().search_URL1 === "") {
				(sap.ui.getCore().search_URL) += ("MatDoc%20eq%20%27" + "" + "%27%20and%20");
				sap.ui.getCore().search_URL = (sap.ui.getCore().search_URL).slice(0, -6);
			} else {
				sap.ui.getCore().search_URL = sap.ui.getCore().search_URL1;
			}
			model.read(sap.ui.getCore().search_URL, null, null, true, function (oResponse) {
				var data = oResponse.results;
				if (data.length === 0) {
					that.showAlert("No Record Found");
					var tab = sap.ui.getCore().homeThis.getView().byId("tabContainer");
					var tab1 = sap.ui.getCore().byId("STEP" + (sap.ui.getCore().SelectedKey));
					//	tab.setEnabled(true);
					sap.ui.getCore().ctabitemid = tab1;
					tab.setSelectedKey(sap.ui.getCore().SelectedKey);
					tab1.setEnabled(true);
					sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey).setVisible(true);
					sap.ui.getCore().busy_dialogIBPS.close();
				} else {
					sap.ui.getCore().Search_Result = data;
					//	that.bindListItem();
					//
					var tab = sap.ui.getCore().homeThis.getView().byId("tabContainer");
					var tab1 = sap.ui.getCore().byId("STEP" + (++sap.ui.getCore().SelectedKey));
					//	tab.setEnabled(true);
					sap.ui.getCore().ctabitemid = tab1;
					tab.setSelectedKey(sap.ui.getCore().SelectedKey);
					tab1.setEnabled(true);
					sap.ui.getCore().busy_dialogIBPS.close();
					sap.ui.getCore().homeThis.bindListItem();
				}
			});

			sap.ui.getCore().homeThis.detailBindFooterButton(sap.ui.getCore().ctabitemid);

			//	that.addTabFilterAndContent(0, sap.ui.getCore().positionData, function() {});

		},
		bindListItem: function () {
			var that = this;
			//	var list = that.getView().byId("idListInbDel");
			var tabFilter = sap.ui.getCore().byId("STEP" + (sap.ui.getCore().SelectedKey));

			var oList = sap.ui.getCore().byId("LIST_" + (sap.ui.getCore().SelectedKey));
			var itemTemplate = sap.ui.getCore().byId("LISTtemplate_" + (sap.ui.getCore().SelectedKey))
				/*		var oList = new sap.m.List("LIST"+sap.ui.getCore().SelectedKey, {
										inset: false,
									
									});
					
					
					
					
					
						var itemTemplate = new sap.m.ObjectListItem({

							title: "PO Number: {PoNumber}",
							number: "{ItemNo}",
							numberUnit: "{data4}",
							type:"Navigation",
						    press: function (e) {
												that.onPressList(e);
											},
								firstStatus: [new sap.m.ObjectStatus({
									text: "Items"
								})
								
								
							],
							attributes: [new sap.m.ObjectAttribute({
									text: "Vendor: {VendorName}"
								}),
								new sap.m.ObjectAttribute({
									text: "PO Date: {CreatedOn}"
								})
								
							]
						}).addStyleClass("rev_objLst");*/

			var model = new sap.ui.model.json.JSONModel();
			model.setData({
				modelData: sap.ui.getCore().Search_Result
			});

			//	model.setSizeLimit(sap.ui.getCore().Search_Result_InbDel.length);

			//var cotentleft=new sap.m.contentLeft();
			/*	var listHeaderBar = new sap.m.Bar({
					width:"100%",
				 	id:"bar_"+sap.ui.getCore().SelectedKey,
						contentLeft : [
							new sap.m.SearchField({
								id:"inpsearch"+(sap.ui.getCore().SelectedKey),
								placeholder:"Search",
								width:"85%",
								tooltip:"Search Item",
								liveChange: function (e) {
										that.onSearchPoList(e);
									},
								search: function (e) {
										that.onSearchPoList(e);
									}
								 }
								),
							new sap.m.Button({
								id:"btnscan"+(sap.ui.getCore().SelectedKey),
								icon : "sap-icon://bar-code",
							 tooltip:"barcode",
							 width:"15%" 
								
								
							}).addStyleClass("Class_Scanbtn")
							
							],
						
					});*/

			//	<SearchField id="SEARCHFIELD_MultiPo" liveChange="onSearch" search="onSearch" width="85%" placeholder="Search" tooltip="Search Item"></SearchField>
			//							<Button icon="sap-icon://bar-code" tooltip="barcode" width="15%" press="onMultiPoBar"/></contentLeft>

			//	cotentleft.addContent(btn);
			//	listHeaderBar.addContent(btn);
			//		

			oList.setModel(model);
			oList.bindAggregation("items", "/modelData", itemTemplate);
			//	var tabFilter=sap.ui.getCore().byId("STEP"+(sap.ui.getCore().SelectedKey))
			//  tabFilter.destroyContent();
			//	this.getView().byId("SEARCHFIELD_InbDel").setValue("");
			/*	var pnl = new sap.m.Panel({
						        id:"pnlTAB_"+sap.ui.getCore().SelectedKey,
								title: new sap.ui.core.Title({
									text: ""
								}),
								content: oList
							});*/

			/*		var pnl=sap.ui.getCore().byId("pnlTAB_"+(sap.ui.getCore().SelectedKey))
			pnl.destroyContent();		
		
			pnl.addContent(oList);
			var oScrollContainer = new sap.m.ScrollContainer({ vertical:true,
					focusable: true, 
					content:[pnl]
						
					}).addStyleClass("heightlist");	
		
			tabFilter.addContent(listHeaderBar);
			tabFilter.addContent(oScrollContainer);*/

			that.setNumbersToIconTabFilter();
		},
		onPressList: function (event) {
			var that = this;
			that.setNumbersToIconTabFilter();
			var item = event.getParameter("listItem") || event.getSource();
			var path = item.getBindingContext().getPath();
			var id = sap.ui.getCore().byId("LIST_" + sap.ui.getCore().SelectedKey);
			var temp = sap.ui.getCore().listtemplate;
			sap.ui.getCore().selectedListData = id.getModel().getProperty(path);
			var selectedPo = sap.ui.getCore().selectedListData.PoNumber;
			sap.ui.getCore().selectedPoNum = selectedPo;

			//	sap.ui.getCore().selectedPoNum="4500001255";
			sap.ui.getCore().movement_type = "101";
			sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey).setVisible(false);
			sap.ui.getCore().byId("bar_" + sap.ui.getCore().SelectedKey).setVisible(false);
			var tab = that.getView().byId("tabContainer");
			//	 that.getView().byId("idSearchID").setVisible(false);
			//	 that.getView().byId("idConfirmID").setVisible(true);
			var tab1 = sap.ui.getCore().byId("STEP" + (++sap.ui.getCore().SelectedKey));
			//	tab.setEnabled(true);
			sap.ui.getCore().ctabitemid = "STEP" + sap.ui.getCore().SelectedKey;
			tab.setSelectedKey(sap.ui.getCore().SelectedKey);
			tab1.setEnabled(true);
			var c = tab1.getContent();
			sap.ui.getCore().SelectedKey = "3";
			//	sap.ui.getCore().byId("pnlTAB_"+sap.ui.getCore().SelectedKey).setVisible(true);
			var list = sap.ui.getCore().byId("LST_" + (sap.ui.getCore().SelectedKey));

			//	var template = sap.ui.getCore().ItemListTemplatePo;
			var Jmodel = new sap.ui.model.json.JSONModel();

			var model = new sap.ui.model.odata.ODataModel("/WMS900/sap/opu/odata/CRVWM/WMS_SRV");
			model.read("/Get_PoItem_DetailsSet?$filter=PoNumber%20eq%20%27" + sap.ui.getCore().selectedPoNum +
				"%27%20and%20MoveType%20eq%20%27" + sap.ui.getCore().movement_type + "%27",
				null, null, true,
				function (oResponse) {
					var data = oResponse.results;
					sap.ui.getCore().POITM_DET = data;
					Jmodel.setData({
						modelData: sap.ui.getCore().POITM_DET
					});
					list.setModel(Jmodel);
					list.bindAggregation("items", "/modelData", temp);
					var tabFilter = sap.ui.getCore().byId("STEP" + (sap.ui.getCore().SelectedKey));
					var pnlid = sap.ui.getCore().byId("pnlTAB_" + (sap.ui.getCore().SelectedKey));
					var pnlheaderid = sap.ui.getCore().byId("pnlheaderTAB_" + (sap.ui.getCore().SelectedKey));
					var z = pnlheaderid.getContent();
					if (pnlid === undefined) {
						// pnlid.destroyContent();
						var pnl = new sap.m.Panel({
							id: "pnlTAB_" + sap.ui.getCore().SelectedKey,
							headerText: "Line Item",
							title: new sap.ui.core.Title({
								text: ""
							}),
							content: list

						});
					} else {
						tabFilter.setEnabled(true);
						var c = tab1.getContent();
						tabFilter.addContent(pnlid);
						// sap.ui.getCore().byId("pnlTAB_ST_"+(sap.ui.getCore().SelectedKey)).setVisible(true);
						that.setNumbersToIconTabFilter();

					}
					var view = that.getView();
					if (sap.ui.getCore().selectedPoNum !== "") {
						model.read("/Get_POheader_DetailsSet('" + sap.ui.getCore().selectedPoNum + "')", null, null, true, function (oResponse) {
							var data = oResponse;
							sap.ui.getCore().PO_HDR_set = data;

							if (sap.ui.getCore().PO_HDR_set.length !== 0) {
								for (var k = 0; k < (sap.ui.getCore().datastep3).length; k++) {

									if (sap.ui.getCore().datastep3[k].ItemType === "HEAD") {

										sap.ui.getCore().byId("txt_" + sap.ui.getCore().datastep3[k].FieldName).setText(sap.ui.getCore().PO_HDR_set[sap.ui.getCore()
											.datastep3[k].FieldName]);

									}
								}
							}

						});

					}

					that.detailBindFooterButton(sap.ui.getCore().ctabitemid);

				});

		},

		onSelectItemDetailList: function (oEvent) {
			var that = sap.ui.getCore().homeThis;
			that.setNumbersToIconTabFilter();
			var item = oEvent.getParameter("listItem") || oEvent.getSource();
			var path = item.getBindingContext().getPath();
			var itemdetaillist = sap.ui.getCore().byId("LST_" + (sap.ui.getCore().SelectedKey));
			//	sap.ui.getCore().psidBindFlag = true;
			sap.ui.getCore().selectedSinglePoItem = itemdetaillist.getModel().getProperty(path);
			sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey).setVisible(false);
			//	sap.ui.getCore().byId("bar_"+sap.ui.getCore().SelectedKey).setVisible(false);
			sap.ui.getCore().byId("pnlheaderTAB_" + (sap.ui.getCore().SelectedKey)).setVisible(false);

			var tab = that.getView().byId("tabContainer");
			//	 that.getView().byId("idSearchID").setVisible(false);
			//	 that.getView().byId("idConfirmID").setVisible(true);
			var tab1 = sap.ui.getCore().byId("STEP" + (++sap.ui.getCore().SelectedKey));
			var pnl = sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey);
			var vbox = sap.ui.getCore().byId("idvboxitemno");
			var hbox = sap.ui.getCore().byId("idhboxitemno");

			//	sap.ui.getCore().selectedSinglePoItem
			//	sap.ui.getCore().datastep4.filter()

			//	tab.setEnabled(true);
			sap.ui.getCore().ctabitemid = "STEP" + sap.ui.getCore().SelectedKey;
			tab.setSelectedKey(sap.ui.getCore().SelectedKey);
			tab1.setEnabled(true);
			var c = tab1.getContent();
			sap.ui.getCore().SelectedKey = "4";
			tab1.setVisible(true);
			vbox.addItem(hbox);
			tab1.addContent(vbox);
			tab1.addContent(pnl);
			sap.ui.getCore().byId("pnlTAB_" + sap.ui.getCore().SelectedKey).setVisible(true);

			sap.ui.getCore().datastep4.filter(function (item) {
				if (item.InputType === "TB" && item.FieldName !== "*") {

					//id:item.InputType+"_"+item.FieldName+"_"+data[i].UiPosition
					sap.ui.getCore().byId(item.InputType + "_" + item.FieldName + "_" + sap.ui.getCore().SelectedKey).setText(sap.ui.getCore().selectedSinglePoItem[
						item.FieldName]);

				} else if (item.InputType === "DD") {
					var val = sap.ui.getCore().selectedSinglePoItem[item.FieldName];
					if (val === "" || val === null) {
						val = "1";

					}
					sap.ui.getCore().byId("dd_" + item.FieldName + "_" + sap.ui.getCore().SelectedKey).setSelectedKey(val);
				} else if (item.InputType === "EB" && item.FieldName !== "*") {

					//id:item.InputType+"_"+item.FieldName+"_"+data[i].UiPosition
					sap.ui.getCore().byId(item.InputType + "_" + item.FieldName + "_" + sap.ui.getCore().SelectedKey).setValue(sap.ui.getCore().selectedSinglePoItem[
						item.FieldName]);

				}

			});

			that.setNumbersToIconTabFilter();
			that.detailBindFooterButton(sap.ui.getCore().ctabitemid);
		},

		onSearchPoList: function (oEvent) {
			var searchString;
			searchString = (oEvent.mParameters.newValue === undefined) ? oEvent.mParameters.query : oEvent.mParameters.newValue;
			if (searchString && searchString.length > 0) {
				var binding = sap.ui.getCore().byId("LIST_" + sap.ui.getCore().SelectedKey).getBinding("items");
				if (!searchString) {
					binding.filter([]);
				} else {
					binding.filter([new sap.ui.model.Filter([
						new sap.ui.model.Filter("PoNumber", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("VendorName", sap.ui.model.FilterOperator.Contains, searchString),
						new sap.ui.model.Filter("OpenQuantity", sap.ui.model.FilterOperator.Contains, searchString)
					], false)]);
				}
			} else {
				binding = sap.ui.getCore().byId("LIST_" + sap.ui.getCore().SelectedKey).getBinding("items");
				if (!searchString) {
					binding.filter([]);
				}
			}
		},

		onConfirmID: function () {
			var that = this;
			sap.ui.core.UIComponent.getRouterFor(that).navTo("Form", {});
		},

		onscan: function (event) {
			var that = this;
			var id = event.getParameter("id");
			var fields = id.split("_");
			//	var funcname=fields[1];
			var inpid = sap.ui.getCore().byId("QRCODE_" + fields[1] + "_" + fields[2]);
			cordova.plugins.barcodeScanner.scan(function (result) {
				var res = result.text;
				if (res !== null) {
					res = res.replace(/(\r\n|\n|\r)/gm, "");
					inpid.setValue(res);
				}
			});

		},

		onSelectionChanged: function (oEvent) {
			var that = this;
			var lvSelectedKey = oEvent.getParameter("selectedKey");
			var tab = that.getView().byId("tabContainer");
			if (lvSelectedKey === "1") {
				sap.ui.getCore().SelectedKey = "1";
				tab.setSelectedKey(sap.ui.getCore().SelectedKey);
				sap.ui.getCore().byId("pnlTAB_" + lvSelectedKey).setVisible(true);
				//	that.getView().byId("idConfirmID").setVisible(false);

				//	that.getView().byId("idSearchID").setVisible(true);
			}
			if (lvSelectedKey === "2") {
				sap.ui.getCore().SelectedKey = "2";
				tab.setSelectedKey(sap.ui.getCore().SelectedKey);
				sap.ui.getCore().byId("pnlTAB_" + lvSelectedKey).setVisible(true);
				//	that.getView().byId("idSearchID").setVisible(false);
				//	that.getView().byId("idConfirmID").setVisible(false);

			}
			if (lvSelectedKey === "3") {
				sap.ui.getCore().SelectedKey = "3";
				tab.setSelectedKey(sap.ui.getCore().SelectedKey);
				sap.ui.getCore().byId("pnlTAB_" + lvSelectedKey).setVisible(true);
				sap.ui.getCore().byId("pnlheaderTAB_" + lvSelectedKey).setVisible(true);
				//	that.getView().byId("idSearchID").setVisible(false);
				//			 that.getView().byId("idSearchID").setVisible(false);
				// that.getView().byId("idConfirmID").setVisible(true);

			}
			if (lvSelectedKey === "4") {
				sap.ui.getCore().SelectedKey = "4";
				tab.setSelectedKey(sap.ui.getCore().SelectedKey);
				sap.ui.getCore().byId("pnlTAB_" + lvSelectedKey).setVisible(true);
				//	sap.ui.getCore().byId("pnlheaderTAB_"+lvSelectedKey).setVisible(true);
				//	that.getView().byId("idSearchID").setVisible(false);
				//			 that.getView().byId("idSearchID").setVisible(false);
				// that.getView().byId("idConfirmID").setVisible(true);

			}

			that.detailBindFooterButton(sap.ui.getCore().ctabitemid);

		},

		setNumbersToIconTabFilter: function () {
			//note: set custom icon on icontab bar	
			setTimeout(function () {
				var data = sap.ui.getCore().positionData;
				for (var i = 0; i < data.length; i++) {
					//Add Tab Content
					if (data[i].Active === "X" && data[i].ItemType === "STEP" && data[i].SubItmId === "GR00")

					{
						$("#STEP" + data[i].UiPosition + "-icon").children("span").prevObject[0].dataset.sapUiIconContent = data[i].UiPosition;

					}
				}
			}, 400);
		},
		addDropDown: function (item, tabno, entityid) {
			/*	var userdata = [{
					key1: "101"
				}, {
					key1: "103"
				}
				];*/
			
			var dropDown = new sap.m.Select({
				id: "dd_" + item + "_" + tabno,
				width: "50%",
				showSecondaryValues: true

			});
			var itemTemplate = new sap.ui.core.ListItem({
				text: "{MovTyp}",
				key: "{MovDesc}",
				additionalText: "{MovDesc}"

			});
			/*	var itemTemplateStocktype = new sap.ui.core.ListItem({
					text: "{SpecialStock}--{SstockDesc}",
					key: "{SpecialStock}"
					//additionalText:"{MovDesc}"
					
				});*/
			if (item === "SpecialStock") {
				entityid = "Get_Special_StockSet";
				itemTemplate = new sap.ui.core.ListItem({
					text: "{SpecialStock}--{SstockDesc}",
					key: "1{SpecialStock}"
						//additionalText:"{MovDesc}"

				});
			}
			var model = new sap.ui.model.odata.ODataModel("/WMS900/sap/opu/odata/CRVWM/WMS_SRV");

			model.read("/" + entityid, null, null, false, function (oResponse) {
				sap.ui.getCore().movedata = oResponse.results;
			});
			var jModel = new sap.ui.model.json.JSONModel();
			jModel.setData({
				userData: sap.ui.getCore().movedata
			});
			dropDown.setModel(jModel);
			dropDown.bindItems("/userData", itemTemplate);
			return dropDown;

			//	sap.ui.getCore().MovType = this.getView().byId("select_mvtType_ibposearch");
			/*	var jModelM = new sap.ui.model.json.JSONModel();
				jModelM.setData({
					userDataM: sap.ui.getCore().movedata
				});
				sap.ui.getCore().MovType.setModel(jModelM);*/

		},
		addPositionData: function (i, positions, data, success) {
			//	swikriti changes 05-09
			if (data.length + 1 === i) {
				return success();
			}

			data.filter(function (item) {
				if (item.UiPosition === "" + positions[i - 1] + "") {
					return sap.ui.getCore().positionData.push(item);
				}
			});
			//	swikriti changes 05-09
			i++;
			//
			this.addPositionData(i, positions, data, success);
		},

		getTabContentByPosition: function (i, j, tabContent, newData, success) {

			if (tabContent.length + 1 === i) {
				return success();
			}
			//	j.sort();
			j.sort(function (a, b) {
				return a - b
			});
			var flag = false;
			tabContent.filter(function (item) {
				if (item.UiPosition.match("" + j[i - 1] + "")) {
					newData.filter(function (item1) {
						if (item1.UiPosition.match("" + j[i - 1] + "")) {
							flag = true;
							return "";
						}
					});
					if (!flag) {
						newData.push(item);
					}
				}
			});
			i++;
			this.getTabContentByPosition(i, j, tabContent, newData, success);
		},

		addTabFilterAndContent: function (i, data, success) {
			var that = sap.ui.getCore().homeThis;
			try {
				if (i === data.length) {
					return true;
					//return success();
				}
				var TModel = this.getView().getModel();
				var fieldData = [];
				var fieldData1 = [];
				var newData = [];
				var view = this.getView();
				sap.ui.getCore().x[i].destroyContent();

				//	$("#TAB"+(i+1)).destroyContent();

				var tabFilter = sap.ui.getCore().x[i];
				var positions = [];
				var tabContent;
				var tableData = [];
				//	sap.ui.getCore().Listdata=[];
				//	tabFilter.destroyContent();

				sap.ui.getCore().VideoPanel = new sap.m.Panel({
					width: "100%"
				});

				jQuery.sap.require("com.crave.DynamicPicking.js.SignaturePad");

				sap.ui.getCore().SignaturePad = new com.crave.DynamicPicking.js.SignaturePad();
				//	var url = sap.ui.getCore().byId("SignatureImage").getSrc();
				if (data[i].InputType === "TB") {
					tabContent = sap.ui.getCore().FieldConfigSet1.filter(function (item) {
						if (item.SubItmId === "GR00" && item.ItemType === "SER" &&
							item.ItmId === data[i].ItmId && item.Active.match("X") && item.InputType !== "BTN") {
							positions.push(item.UiPosition);
							//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
							return item;
						}
					});

				} else if (data[i].InputType === "") {
					tabContent = sap.ui.getCore().FieldConfigSet1.filter(function (item) {
						//	if(item.ItemType === "SER")
						if (item.SubItmId === data[i].ItmId) {
							if (item.SubItmId === data[i].ItmId && item.Active.match("X") && item.InputType !== "BTN") {
								positions.push(item.UiPosition);
								if (data[i].UiPosition === "1") {
									(sap.ui.getCore().step1).push(item);
									sap.ui.getCore().datastep1 = sap.ui.getCore().step1;
								} else if (data[i].UiPosition === "2") {
									(sap.ui.getCore().step2).push(item);
									sap.ui.getCore().datastep2 = sap.ui.getCore().step2;
								} else if (data[i].UiPosition === "3") {
									(sap.ui.getCore().step3).push(item);
									sap.ui.getCore().datastep3 = sap.ui.getCore().step3;
								} else if (data[i].UiPosition === "4") {
									(sap.ui.getCore().step4).push(item);
									sap.ui.getCore().datastep4 = sap.ui.getCore().step4;
								}

								//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
								return item;
							}
						}
						/*	if(item.ItemType === "LST"){
								
							if (item.SubItmId === data[i].ItmId && item.Active.match("X") && item.InputType !== "BTN") {
								positions.push(item.UiPosition);
								//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
								(sap.ui.getCore().Listdata).push(item);
								return item;
							
							}
							}
							
								if(item.ItemType === "HEAD" ){
								
							if (item.SubItmId === data[i].ItmId && item.Active.match("X") && item.InputType !== "BTN") {
								positions.push(item.UiPosition);
								//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
								(sap.ui.getCore().Listdata).push(item);
								return item;
							
							}
							}*/

					});
					sap.ui.getCore().newData1 = [];
					var z = 0;
					for (var m = 0; m < tabContent.length; m++) {

						var val = ++z;
						tabContent.filter(function (item) {
							if (item.UiPosition === (val).toString()) {
								sap.ui.getCore().newData1.push(item);
							}

						});
					}

					tabContent = sap.ui.getCore().newData1;

				} else if (data[i].InputType === "0") {
					tabContent = sap.ui.getCore().FieldConfigSet1.filter(function (item) {
						if (item.ItemType === "SER" || item.ItemType === "COL") {
							if (item.SubItmId === "GR00" && item.ItmId === data[i].ItmId && item.Active.match("X") && item.InputType !== "BTN") {
								positions.push(item.UiPosition);
								//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
								return item;
							}
						}
					});

				} else if (data[i].InputType === "TL") {
					tabContent = sap.ui.getCore().FieldConfigSet1.filter(function (item) {
						if (item.SubItmId === "GR00" && item.ItemType === "COL" && item.ItmId === data[i].ItmId && item.Active.match(
								"X")) {
							positions.push(item.UiPosition);
							//	sap.ui.getCore().detailThis.detailBindFooterButton(item.ItmId);
							return item;
						}
					});
				} else if (data[i].InputType === "QR") {
					/*var qrfield  = new sap.m.Input("QRCODE", {
						editable: true
					});*/
					var fields = [
						new sap.m.Input("QRCODE", {
							editable: true,
							width: "40%"
						}),
						new sap.m.Button({
							text: "Scan",
							width: "30%",
							icon: "sap-icon://bar-code",
							press: view.getController().onscan
						}).addStyleClass("x")

					];
					var oSimpleForm = new sap.m.Panel({
						title: new sap.ui.core.Title({
							text: ""
						}),
						//content: qrfield
						content: fields
					});
					tabFilter.destroyContent();
					tabFilter.addContent(oSimpleForm);

				} else if (data[i].InputType === "EB") {
					/*var qrfield  = new sap.m.Input("QRCODE", {
						editable: true
					});*/
					var fields = [
						new sap.m.Input({
							id: "eb_" + (item.FieldLabel).replace(/\s/g, '') + "_" + data[i].UiPosition,
							editable: true,
							width: "30%"
						})

					];
					var oSimpleForm = new sap.m.Panel({
						title: new sap.ui.core.Title({
							text: ""
						}),
						//content: qrfield
						content: fields
					});
					tabFilter.addContent(oSimpleForm);

				} else if (data[i].InputType === "PI") {
					sap.ui.getCore().count = 0;
					var fields = [
						new sap.m.Button({
							//text: "Add Picture",
							text: "Add Document",
							width: "15%",
							icon: "",
							press: this.getView().getController().capturePicture
						}),
						new sap.m.List("imageList", {
							itemPress: view.getController().showImage,
							mode: sap.m.ListMode.Delete,
							"delete": function (e) {
								var path = e.getParameter('listItem').getBindingContext().getPath();
								var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
								var m = this.getModel();
								var d = m.getData();
								// d.splice(idx, 1);
								d.modelData.splice(idx, 1);
								m.setData(d);
								m.refresh(true);
							}
						})

					];
					var oSimpleForm = new sap.m.Panel({
						title: new sap.ui.core.Title({
							text: ""
						}),
						content: fields
					});
					tabFilter.addContent(oSimpleForm);

					//tabFilter.destroyContent();
					//		sap.ui.getCore().detailThis.detailBindFooterButton("");
				} else if (data[i].InputType === "SG") {
					var fields = [
						new sap.m.Button({
							//text: "Capture Signature",
							text: "{i18n>capturesignatuer}",
							icon: "",
							press: this.getView().getController().captureSignature
						}),
						new sap.m.Label({
							width: "2%"
						}),
						new sap.m.Button({
							//text: "Clear",
							text: "{i18n>clear}",
							icon: "",
							press: this.getView().getController().clearSignature
						}),
						new sap.m.Label({
							width: "20%"
						}),
						new sap.m.HBox({
							items: [sap.ui.getCore().SignaturePad
								/*new sap.crave.dynamic.js.SignaturePad("signaturePad",{
								                    			width : 300,
								                    			height : 150
								                    		})*/
								,
								new sap.m.Image({
									id: 'SignatureImage',
									width: '10em',
									height: '10em',
									visible: false
								})
							]
						})

					];
					var oSimpleForm = new sap.m.Panel({
						title: new sap.ui.core.Title({
							text: ""
						}),
						content: fields
					});

					//		tabFilter.destroyContent();
					tabFilter.addContent(oSimpleForm);
					//		sap.ui.getCore().detailThis.detailBindFooterButton("");
				} else if (data[i].InputType === "MD") {
					var fields = [
						/*new sap.m.Button({
							width: "21%",
							text: "Capture Audio",
							icon: "sap-icon://microphone",
							press: function(oEvent) {
								try {
									navigator.device.capture.captureAudio(view.getController().captureSuccess, view.getController().captureError, {
										limit: 2
									});
								} catch (e) {
									alert("capturePicture Exception: " + e.message);
								}
							}
						}),*/
						new sap.m.Label({
							width: "1%"
						}),
						/*new sap.m.Button({
							type: "Default",
							text: "Play Audio",
							icon: "sap-icon://microphone",
							press: view.getController().onAudioPress
						}),
						new sap.m.Label({
							width: "1%"
						}),
						new sap.m.Label({
							text: "- OR -"
						}),
						new sap.m.Label({
							width: "1%"
						}),*/
						new sap.m.Button({
							width: "21%",
							text: "Capture Video",
							icon: "sap-icon://video",
							press: function (oEvent) {
								try {
									if (jQuery.device.is.desktop) {
										navigator.getMedia = (navigator.getUserMedia || navigator.webkitGetUserMedia ||
											navigator.mozGetUserMedia || navigator.msGetUserMedia);
										navigator.getMedia({
											video: true
										}, function (obj) {
											console.log(obj);
										}, function (err) {
											//sap.m.MessageToast.show(err,{width:"20rem"})
											navigator.notification.alert(err, null, "Capture Error", null);
										});

									} else {
										navigator.device.capture.captureVideo(view.getController().videoCaptureSuccess, view.getController().videoCaptureError, {
											limit: 2
										});
									}
								} catch (e) {
									//alert("capturePicture Exception: " + e.message);
									navigator.notification.alert(e.message, null, "capturePicture Exception", null);
								}
							}
						}),
						new sap.m.Label({
							width: "1%"
						}),
						new sap.m.Button({
							type: "Default",
							text: "Play Video",
							icon: "sap-icon://video",
							press: view.getController().onVideoPress
						}),
						sap.ui.getCore().VideoPanel

					];
					var oSimpleForm = new sap.m.Panel({
						title: new sap.ui.core.Title({
							text: ""
						}),
						content: fields
					});

					//		tabFilter.destroyContent();
					tabFilter.addContent(oSimpleForm);
					//		sap.ui.getCore().detailThis.detailBindFooterButton("");
				}
				if (tabContent !== undefined) {
					var x = [];
				
					var oSimpleFormTable;
					var oTable;
					this.getTabContentByPosition(1, positions, tabContent, newData, function () {
						if (data[i].InputType === "TL") {

							oSimpleFormx = new sap.m.List({
								id: "LST_" + data[i].UiPosition,
								mode: "MultiSelect",
								//selectionChange: this.getView().getController().onSelectionChange
							});

							var template = new sap.m.CustomListItem({
								//	id:"Template_"+data[i].UiPosition,
								type: sap.m.ListType.Navigation,
								//	press: this.getView().getController().onSelectList,
								content: new sap.m.HBox({
									items: [new sap.m.VBox({
										width: "90%",
										items: [new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Item No- {ItemNo}"
													}).addStyleClass("textColor")
												}), new sap.m.VBox({
													width: "50%"
												})]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Material No"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{Material}"
													})
												})]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Material Description"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{MaterialDes}"
													})
												})]
											}),

											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Open Quantity"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{OpenQuantity}"
													})
												})]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Quantity"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Input("PID_INP", {
														value: {
															path: 'inp_qty',
															type: new sap.ui.model.type.Integer()
														},
														width: "30%"
													}).addStyleClass("sapUiSizeCompact")
												})]
											})

										]
									})]
								})
							}).addStyleClass(" pdng rev_objLst space_ObjLstItem");

							sap.ui.getCore().oSimpleFormx = oSimpleForm;
							sap.ui.getCore().listtemplate = template;

						} else if (data[i].screen === "LIST") {

							var oList = new sap.m.List("LIST_" + data[i].UiPosition, {
								inset: false,

							});

							var itemTemplate = new sap.m.ObjectListItem({
								id: "LISTtemplate_" + data[i].UiPosition,
								title: "PO Number: {PoNumber}",
								number: "{ItemNo}",
								numberUnit: "{data4}",
								type: "Navigation",
								press: function (e) {
									that.onPressList(e);
								},
								firstStatus: [new sap.m.ObjectStatus({
										text: "Items"
									})

								],
								attributes: [new sap.m.ObjectAttribute({
										text: "Vendor: {VendorName}"
									}),
									new sap.m.ObjectAttribute({
										text: "PO Date: {CreatedOn}"
									})

								]
							}).addStyleClass("rev_objLst");

							var listHeaderBar = new sap.m.Bar({
								width: "100%",
								id: "bar_" + data[i].UiPosition,
								contentLeft: [
									new sap.m.SearchField({
										id: "inpsearch" + (sap.ui.getCore().SelectedKey),
										placeholder: "Search",
										width: "85%",
										tooltip: "Search Item",
										liveChange: function (e) {
											that.onSearchPoList(e);
										},
										search: function (e) {
											that.onSearchPoList(e);
										}
									}),
									new sap.m.Button({
										id: "btnscan" + data[i].UiPosition,
										icon: "sap-icon://bar-code",
										tooltip: "barcode",
										width: "15%"

									}).addStyleClass("Class_Scanbtn")

								],

							});

							//	oList.setModel(model);
							//	oList.bindAggregation("items", "/modelData", itemTemplate);
							var tabFilter = sap.ui.getCore().byId("STEP" + data[i].UiPosition);
							//  tabFilter.destroyContent();
							//	this.getView().byId("SEARCHFIELD_InbDel").setValue("");
							var pnl = new sap.m.Panel({
								id: "pnlTAB_" + data[i].UiPosition,
								title: new sap.ui.core.Title({
									text: ""
								}),
								content: oList
							});

							//var pnl=sap.ui.getCore().byId("pnlTAB_"+(sap.ui.getCore().SelectedKey))
							//	pnl.destroyContent();		

							pnl.addContent(oList);
							var oScrollContainer = new sap.m.ScrollContainer({
								vertical: true,
								focusable: true,
								content: [pnl]

							}).addStyleClass("heightlist");

							tabFilter.addContent(listHeaderBar);
							tabFilter.addContent(oScrollContainer);

						} else if (data[i].screen === "LIST - DETAIL") {

							oSimpleFormx = new sap.m.List({
								id: "LST_" + data[i].UiPosition,
								mode: "MultiSelect",
								//selectionChange: this.getView().getController().onSelectionChange
							});

							/*	var template = new sap.m.CustomListItem({
							 	id:"LISTDETAILtemplate_"+data[i].UiPosition,
								type: sap.m.ListType.Navigation,
							//	press: this.getView().getController().onSelectList,
								content: new sap.m.HBox({
									items: [new sap.m.VBox({
										width: "90%",
										items: [
											new sap.m.HBox({
												items: [
													new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Item No- {ItemNo}"
													}).addStyleClass("textColor")
												}),
												new sap.m.VBox({
													width: "50%"
												})
												]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Material No"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{Material}"
													})
												})]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Material Description"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{MaterialDes}"
													})
												})]
											}),

											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Open Quantity"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														text: "{OpenQuantity}"
													})
												})]
											}),
											new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "50%",
													items: new sap.m.Label({
														design: sap.m.LabelDesign.Bold,
														text: "Quantity"
													}).addStyleClass("textColor prewrap")
												}), new sap.m.VBox({
													width: "50%",
													items: new sap.m.Input("PID_INP_"+data[i].UiPosition, {
														value: {
															path: 'inp_qty',
															type: new sap.ui.model.type.Integer()
														},
														width: "30%"
													}).addStyleClass("sapUiSizeCompact")
												})]
											})
										
										]
									})]
								})
							}).addStyleClass(" pdng rev_objLst space_ObjLstItem");*/

							var outerhbox = new sap.m.HBox({});
							var outervbox = new sap.m.VBox({
								width: "90%"

							});
							var pnl = new sap.m.Panel({
								id: "pnlTAB_" + data[i].UiPosition,
								title: new sap.ui.core.Title({
									text: "Line Item"
								}),
								//	content: oSimpleFormx
							});

							outervbox.addItem();

							for (var k = 0; k < (sap.ui.getCore().datastep3).length; k++) {

								if (sap.ui.getCore().datastep3[k].ItemType === "LIST") {
									var innerhbox = new sap.m.HBox({});

									var vboxlabel = new sap.m.VBox({
										width: "50%",
										items: new sap.m.Label({
											design: sap.m.LabelDesign.Bold,
											text: sap.ui.getCore().datastep3[k].FieldName
										}).addStyleClass("textColor")
									});
									var vboxtext = new sap.m.VBox({
										width: "50%",
										items: new sap.m.Label({
											text: "{" + sap.ui.getCore().datastep3[k].FieldName + "}"
										})
									});

									innerhbox.addItem(vboxlabel);
									innerhbox.addItem(vboxtext);
									outervbox.addItem(innerhbox);

								}
								if (sap.ui.getCore().datastep3[k].ItemType === "BARC") {
									var oBar = new sap.m.Bar({
										design: sap.m.BarDesign.Auto,
										width: "100%",
										contentLeft: [

											new sap.m.SearchField({
												id: sap.ui.getCore().datastep3[k].FieldLable + "_" + data[i].UiPosition,
												tooltip: "Search Item",
												search: "onSearch",
												width: "85%",
												placeholder: "Search",
												liveChange: "onSearch"
											}),

											new sap.m.Button({
												icon: "sap-icon://bar-code",
												tooltip: "barcode",
												width: "15%"

											})

										]

									});
									pnl.addContent(oBar);

								}

							}

							outerhbox.addItem(outervbox);
							//		var view = this.getView();
							var template = new sap.m.CustomListItem({
								id: "LISTDETAILtemplate_" + data[i].UiPosition,
								type: sap.m.ListType.Navigation,
								content: outerhbox,
								press: that.getView().getController().onSelectItemDetailList
									/* press: function (e) {
							sap.ui.getCore().homeThis.onSelectItemDetailList(e);
									}*/

							}).addStyleClass(" pdng rev_objLst space_ObjLstItem");

							sap.ui.getCore().oSimpleFormx = oSimpleForm;
							sap.ui.getCore().listtemplate = template;

							//	var pnl1=that.BindHeaderData(data[i].UiPosition);
							//	       	var x=sap.ui.getCore().headertemplate;

							var pnlheader = new sap.m.Panel({
								id: "pnlheaderTAB_" + data[i].UiPosition,
								title: new sap.ui.core.Title({
									text: ""
								})

							}).addStyleClass("hdr_panel");

							//var pnl1 = view.byId("pnlheaderTAB_"+position);

							for (var k = 0; k < (sap.ui.getCore().datastep3).length; k++) {

								if (sap.ui.getCore().datastep3[k].ItemType === "HEAD") {

									var lbl = new sap.m.Label({
										design: sap.m.LabelDesign.Bold,
										text: sap.ui.getCore().datastep3[k].FieldName,
										width: "50%"
									}).addStyleClass("hdr_text");
									var txt = new sap.m.Label({
										design: sap.m.LabelDesign.Bold,
										text: "",
										width: "50%",
										id: "txt_" + sap.ui.getCore().datastep3[k].FieldName
									}).addStyleClass("hdr_text");

									pnlheader.addContent(lbl);
									pnlheader.addContent(txt);
								}
								//	sap.ui.getCore().XX=pnlheader;					

							}

							var tabFilter = sap.ui.getCore().byId("STEP" + data[i].UiPosition);
							//  tabFilter.destroyContent();
							//	this.getView().byId("SEARCHFIELD_InbDel").setValue("");

							//var pnl=sap.ui.getCore().byId("pnlTAB_"+(sap.ui.getCore().SelectedKey))
							//	pnl.destroyContent();
							/*	var pnl = new sap.m.Panel({
										        id:"pnlTAB_"+data[i].UiPosition,
												title: new sap.ui.core.Title({
													text: "Line Item"
												}),
												content: oSimpleFormx
											});*/

							var oBar = new sap.m.Bar({
								design: sap.m.BarDesign.Auto,
								width: "100%",
								contentLeft: [

									new sap.m.SearchField({
										id: "search_listdetail",
										tooltip: "Search Item",
										search: "onSearch",
										width: "85%",
										placeholder: "Search",
										liveChange: "onSearch"
									}),

									new sap.m.Button({
										icon: "sap-icon://bar-code",
										tooltip: "barcode",
										width: "15%"

									})

								]

							});
							pnl.addContent(oBar);
							pnl.addContent(oSimpleFormx);
							var oScrollContainer = new sap.m.ScrollContainer({
								vertical: true,
								focusable: true,
								content: [pnl]

							}).addStyleClass("");

							tabFilter.addContent(pnlheader);
							tabFilter.addContent(oScrollContainer);
						} else if (data[i].screen === "ITEM DETAIL - CONFIRM") {
							var tabFilter = sap.ui.getCore().byId("STEP" + data[i].UiPosition);
							sap.ui.getCore().datastep4 = newData;

							var outervboxconfirm = new sap.m.VBox({
								id: "idvboxitemno"
							}).addStyleClass("vbox");
							var outerhboxconfirm = new sap.m.HBox({
								id: "idhboxitemno"
							}).addStyleClass("HboxItemNo").addStyleClass("src_Hbox");
							var pnl = new sap.m.Panel({
								id: "pnlTAB_" + data[i].UiPosition,
								title: new sap.ui.core.Title({
									text: ""
								}),
								content: ""
							}).addStyleClass("pnlSingleItemClass");
							var pnloutervbox = new sap.m.VBox({}).addStyleClass("vbox");
							//  var pnlouterhbox=new sap.m.HBox({}).addStyleClass("src_Hbox");	

							sap.ui.getCore().datastep4.filter(function (item) {
								//		var a=item;
								//		 var pnloutervbox=new sap.m.VBox({}).addStyleClass("vbox");	
								var pnlouterhbox = new sap.m.HBox({}).addStyleClass("src_Hbox");
								if (item.ItemType === "DET" && item.InputType !== "BTN") {

									if (item.FieldName === "ItemNo") {
										var lbl = new sap.m.Label({
											design: sap.m.LabelDesign.Bold,
											text: item.FieldLabel,

										}).addStyleClass("itmdet_hdr_text").addStyleClass("sapUiSmallMarginBegin");
										var txt = new sap.m.Label({
											design: sap.m.LabelDesign.Bold,
											text: "",

											id: item.InputType + "_" + item.FieldName + "_" + data[i].UiPosition
										}).addStyleClass("itmdet_hdr_text");

										outerhboxconfirm.addItem(lbl);
										outerhboxconfirm.addItem(txt);
									} else {
										if (item.FieldName !== "*") {
											if (item.InputType === "TB") {
												var lbl1 = new sap.m.Label({

													text: item.FieldLabel,

												}).addStyleClass("bold_text");
												var txt1 = new sap.m.Label({

													text: "",

													id: item.InputType + "_" + item.FieldName + "_" + data[i].UiPosition
												});
												pnlouterhbox.addItem(lbl1);
												pnlouterhbox.addItem(txt1);
												pnloutervbox.addItem(pnlouterhbox);
												pnl.addContent(pnloutervbox);
											} else if (item.InputType === "DD") {

												var tabno = data[i].UiPosition;
												txt1 = sap.ui.getCore().homeThis.addDropDown(item.FieldName, tabno, item.EntyId);
												lbl1 = new sap.m.Label({

													text: item.FieldLabel,

												}).addStyleClass("bold_text");
												pnlouterhbox.addItem(lbl1);
												pnlouterhbox.addItem(txt1);
												pnloutervbox.addItem(pnlouterhbox);
												pnl.addContent(pnloutervbox);

											} else if (item.InputType === "EB") {

												//		var tabno=data[i].UiPosition;
												//	txt1=sap.ui.getCore().homeThis.addDropDown(item.FieldName,tabno,item.EntyId);
												lbl1 = new sap.m.Label({

													text: item.FieldLabel,

												}).addStyleClass("bold_text");

												txt1 = new sap.m.Input({
													id: item.InputType + "_" + item.FieldName + "_" + data[i].UiPosition,
													//  id:"eb_"+(item.FieldName)+"_"+data[i].UiPosition,
													editable: true,
													width: "50%"
												})

												pnlouterhbox.addItem(lbl1);
												pnlouterhbox.addItem(txt1);
												pnloutervbox.addItem(pnlouterhbox);
												pnl.addContent(pnloutervbox);

											}
										}
									}

								}
							});

							outervboxconfirm.addItem(outerhboxconfirm);
							tabFilter.addContent(outervboxconfirm);
							var oScrollContainer = new sap.m.ScrollContainer({
								vertical: true,
								focusable: true,
								//	heigt:"500px",
								content: [pnl]

							}).addStyleClass("");
							//	pnl.addContent(pnloutervbox);
							tabFilter.addContent(oScrollContainer);

						} else {
							newData.filter(function (item) {
								var label = item.FieldLabel;
								// var fieldName = item.FieldName;
								var fieldtype = item.FieldType;
								var inputType = item.InputType;
								var field1;
								if (inputType !== "TL") {
									if (label === undefined) {
										label = "";
									}
									field1 = new sap.m.Label({
										text: label
									}).addStyleClass("sapUiSmallMarginTop");

								}
								var field2;
								var filteredData;
								if (inputType === "FZ") {

									TModel.read("/FUZZYSEARCHSet?$filter=IsEntyId eq '" + data[i].EntyId + "' and IsItmId eq '" + data[i].ItmId +
										"' and IsProfileid eq 'NT_APR' and IsSubItmId eq '" + sap.ui.getCore().SubItmId + "'", null, null, true,
										function (oResponse) {
											//	alert(JSON.stringify(oResponse));
											sap.ui.getCore().fuzzyResult = oResponse.results;
											filteredData = sap.ui.getCore().detailThis.fuzzySearch(sap.ui.getCore().fuzzyResult);
										},
										function (e) {});
								}
								if (fieldtype === "I") {
									var flag = true;
									if (inputType === "TB") {
										flag = false;
										field2 = new sap.m.Input({
											//	str.replace(/\s/g, '')
											id: "inp_" + (item.FieldName) + "_" + data[i].UiPosition,
											editable: flag
										});
									} else if (inputType === "DD") {
										var item1 = item.FieldName;
										var tabno = data[i].UiPosition;
										var entityid = item.EntyId;
										field2 = sap.ui.getCore().homeThis.addDropDown(item1, tabno, entityid);
									} else if (inputType === "DT") {

										field2 = new sap.m.DatePicker({
											id: "dp_" + (item.FieldName) + "_" + data[i].UiPosition,
											displayFormat: "MM/dd/yyyy",
											valueFormat: "MM/dd/yyyy",
											value: "",
											width: "50%"
										});
									} else if (inputType === "FZ") {
										field2 = new sap.m.Input({
											placeholder: "Search",
											showSuggestion: true,
											suggestionItems: "",
											liveChange: function (oEvent) {
												var sValue = oEvent.getParameter("newValue");
												var id = oEvent.getParameters().id;
												//	if(sValue !== ""){
												var aSuggestions = [];
												aSuggestions = filteredData(sValue);
												/*sap.ui.getCore().fuzzyResult.filter(function(items){
													if(items.FzyVal1.indexOf(""+sValue+"") !== -1 || items.FzyVal2.indexOf(""+sValue+"") !== -1){
														return aSuggestions.push(items.FzyVal1+"  "+items.FzyVal2);
													}
												});*/
												//	alert(aSuggestions.length);
												if (aSuggestions.length > 0) {
													var unames = sap.ui.getCore().byId(id);
													var suggestVal = [];
													unames.destroySuggestionItems();
													for (var k = 0; k < aSuggestions.length; k++) {
														suggestVal[k] = aSuggestions[k];
														this.addSuggestionItem(new sap.ui.core.ListItem({
															text: suggestVal[k]
														}));
													}
												}
											}
										});
									} else if (inputType === "QR") {

										field2 = [new sap.m.Input({
												id: "QRCODE_" + (item.FieldName) + "_" + data[i].UiPosition,
												editable: flag
													//	width:"50%"
											}),

											new sap.m.Button({
												text: "Scan",
												id: "scan_" + item.FieldName + "_" + data[i].UiPosition,
												icon: "sap-icon://bar-code",
												width: "35%",
												press: sap.ui.getCore().homeThis.onscan
											}).addStyleClass("x")

										];

									} else if (inputType === "SG") {
										var fieldsg = [];
										jQuery.sap.require("sap.crave.dynamic.js.SignaturePad");

										sap.ui.getCore().SignaturePad = new sap.crave.dynamic.js.SignaturePad();
										var url = "";
										var oSignaturePad = new sap.crave.dynamic.js.SignaturePad({
											width: 300,
											height: 150,
											imageUrl: url
										});
										field2 = [
											new sap.m.Button({
												//text: "Capture Signature",
												text: "{i18n>capturesignatuer}",
												icon: "",
												//width: "40%"
												press: sap.ui.getCore().detailThis.captureSignature
											}),
											/*	new sap.m.Label({
												width: "2%"
											}),*/
											new sap.m.Button({
												//text: "Clear",

												text: "{i18n>clear}",
												icon: "",
												//	width: "70%",
												press: sap.ui.getCore().detailThis.clearSignature
											}),
											new sap.m.Label({
												width: "20%"
											}),
											new sap.m.HBox({
												width: "100%",
												items: [oSignaturePad]
											})
										];

										//	field2.push(fieldsg);

										var oSimpleForm1 = new sap.m.Panel({
											title: new sap.ui.core.Title({
												text: ""
											}),
											content: field2
										});

										//tabFilter.destroyContent();
										//	tabFilter.addContent(oSimpleForm1);

										//	fieldData.push(oSimpleForm1);
									} else if (inputType === "TL") {

										oSimpleFormx = new sap.m.List({
											id: "LST_" + data[i].UiPosition,
											mode: "MultiSelect",
											//selectionChange: this.getView().getController().onSelectionChange
										});

										var template = new sap.m.CustomListItem({
											//	id:"Template_"+data[i].UiPosition,
											type: sap.m.ListType.Navigation,
											//	press: this.getView().getController().onSelectList,
											content: new sap.m.HBox({
												items: [new sap.m.VBox({
													width: "90%",
													items: [new sap.m.HBox({
															items: [new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	design: sap.m.LabelDesign.Bold,
																	text: "Item No- {ItemNo}"
																}).addStyleClass("textColor")
															}), new sap.m.VBox({
																width: "50%"
															})]
														}),
														new sap.m.HBox({
															items: [new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	design: sap.m.LabelDesign.Bold,
																	text: "Material No"
																}).addStyleClass("textColor prewrap")
															}), new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	text: "{Material}"
																})
															})]
														}),
														new sap.m.HBox({
															items: [new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	design: sap.m.LabelDesign.Bold,
																	text: "Material Description"
																}).addStyleClass("textColor prewrap")
															}), new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	text: "{MaterialDes}"
																})
															})]
														}),

														new sap.m.HBox({
															items: [new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	design: sap.m.LabelDesign.Bold,
																	text: "Open Quantity"
																}).addStyleClass("textColor prewrap")
															}), new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	text: "{OpenQuantity}"
																})
															})]
														}),
														new sap.m.HBox({
															items: [new sap.m.VBox({
																width: "50%",
																items: new sap.m.Label({
																	design: sap.m.LabelDesign.Bold,
																	text: "Quantity"
																}).addStyleClass("textColor prewrap")
															}), new sap.m.VBox({
																width: "50%",
																items: new sap.m.Input("PID_INP", {
																	value: {
																		path: 'inp_qty',
																		type: new sap.ui.model.type.Integer()
																	},
																	width: "30%"
																}).addStyleClass("sapUiSizeCompact")
															})]
														})

													]
												})]
											})
										}).addStyleClass(" pdng rev_objLst space_ObjLstItem");

										sap.ui.getCore().oSimpleFormx = oSimpleForm;
										sap.ui.getCore().listtemplate = template;

									} else {
										field2 = new sap.m.Input({
											id: "inp_" + (item.FieldName) + "_" + data[i].UiPosition,
											editable: flag,
											width: "50%"
										});
									}
								} else if (fieldtype === "D" && inputType !== "TL") {
									//	var flag = true;
									//		if (inputType === "TB") {
									//		flag = false;
									if (inputType === "SG") {
										var fieldsg = [];
										jQuery.sap.require("sap.crave.dynamic.js.SignaturePad");

										sap.ui.getCore().SignaturePad = new sap.crave.dynamic.js.SignaturePad();
										var url = "";
										var oSignaturePad = new sap.crave.dynamic.js.SignaturePad({
											width: 300,
											height: 150,
											imageUrl: url
										});
										field2 = [
											new sap.m.Button({
												//text: "Capture Signature",

												text: "{i18n>capturesignatuer}",
												icon: "",
												//width: "80%",
												press: sap.ui.getCore().detailThis.captureSignature
											}),
											/*	new sap.m.Label({
												width: "2%"
											}),*/
											new sap.m.Button({
												//	text: "Clear",

												text: "{i18n>clear}",
												icon: "",
												//width: "40%",
												press: sap.ui.getCore().detailThis.clearSignature
											}),
											new sap.m.Label({
												width: "20%"
											}),
											new sap.m.HBox({
												width: "100%",
												items: [oSignaturePad]
											})
										];

										//	field2.push(fieldsg);

										/*	var oSimpleForm1 = new sap.m.Panel({
													title: new sap.ui.core.Title({
														text: ""
													}),
													content: field2
												});*/

										//tabFilter.destroyContent();
										//	tabFilter.addContent(oSimpleForm1);

										//	fieldData.push(oSimpleForm1);
									} else {
										field2 = new sap.m.Input({
											id: "inp" + (item.FieldLabel).replace(/\s/g, '') + "_" + data[i].UiPosition,
											editable: false
										});
									}
									//		}
								} else if (inputType === "TL") {
									var oSimpleFormx = new sap.m.List({
										id: "LST_" + data[i].UiPosition,
										mode: "MultiSelect",
										//	selectionChange: this.getView().getController().onSelectionChange
									});

									var template = new sap.m.CustomListItem({
										//	id:"Template_"+data[i].UiPosition,
										type: sap.m.ListType.Navigation,
										//	press: this.getView().getController().onSelectList,
										content: new sap.m.HBox({
											items: [new sap.m.VBox({
												width: "90%",
												items: [new sap.m.HBox({
														items: [new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																design: sap.m.LabelDesign.Bold,
																text: "Item No- {ItemNo}"
															}).addStyleClass("textColor")
														}), new sap.m.VBox({
															width: "50%"
														})]
													}),
													new sap.m.HBox({
														items: [new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																design: sap.m.LabelDesign.Bold,
																text: "Material No"
															}).addStyleClass("textColor prewrap")
														}), new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																text: "{Material}"
															})
														})]
													}),
													new sap.m.HBox({
														items: [new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																design: sap.m.LabelDesign.Bold,
																text: "Material Description"
															}).addStyleClass("textColor prewrap")
														}), new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																text: "{MaterialDes}"
															})
														})]
													}),

													new sap.m.HBox({
														items: [new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																design: sap.m.LabelDesign.Bold,
																text: "Open Quantity"
															}).addStyleClass("textColor prewrap")
														}), new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																text: "{OpenQuantity}"
															})
														})]
													}),
													new sap.m.HBox({
														items: [new sap.m.VBox({
															width: "50%",
															items: new sap.m.Label({
																design: sap.m.LabelDesign.Bold,
																text: "Quantity"
															}).addStyleClass("textColor prewrap")
														}), new sap.m.VBox({
															width: "50%",
															items: new sap.m.Input("PID_INP", {
																value: {
																	path: 'inp_qty',
																	type: new sap.ui.model.type.Integer()
																},
																width: "30%"
															}).addStyleClass("sapUiSizeCompact")
														})]
													})

												]
											})]
										})
									}).addStyleClass(" pdng rev_objLst space_ObjLstItem");

									sap.ui.getCore().oSimpleFormx = oSimpleForm;
									sap.ui.getCore().listtemplate = template;

								}

								if (field1 !== undefined) {
									fieldData.push(field1);
								}
								if (field2 !== undefined) {
									fieldData.push(field2);
									/*if (inputType === "QR") {
										fieldData.push(new sap.m.Button({
											icon: "sap-icon://bar-code",
											press: view.getController().onscan
										}));
									}*/
								}
							});
						}

						if (i < data.length) {
							if (data[i].InputType !== "TL") {
								/*if (fieldData !== undefined || fieldData.length > 0) {
									var oSimpleForm = new sap.ui.layout.form.SimpleForm({
										minWidth: 1024,
										maxContainerCols: 0,
										title: new sap.ui.core.Title({
											text: ""
										}),
										content: fieldData
									});

									tabFilter.destroyContent();
									tabFilter.addContent(oSimpleForm);
								}*/

								if (fieldData !== undefined || fieldData.length > 0) {
									var oSimpleFormx = new sap.ui.layout.form.SimpleForm({
										/* minWidth: 1024,
										 width:"100%",
										 /*maxContainerCols: 0,*/
										layout: "ResponsiveGridLayout",

										/* title: new sap.ui.core.Title({
										     text: ""
										 }),*/
										content: fieldData
											//	content: hbox
											//content: 

									});
									var cell = new sap.ui.layout.BlockLayoutCell({
										/*title: new sap.ui.core.Title({
										    text: ""
										}),*/
										content: oSimpleFormx
									});

									var oSimpleForm13 = new sap.ui.layout.BlockLayoutRow({
										/* title: new sap.ui.core.Title({
										     text: ""
										 }),*/
										content: cell
									});

									var oSimpleForm11 = new sap.ui.layout.BlockLayout({
										/*                title: new sap.ui.core.Title({
										                    text: ""
										                }),*/
										content: [oSimpleForm13, oSimpleFormTable]
									});

									if (data[i].InputType !== "TL" && data[i].screen !== "LIST" && data[i].screen !== "LIST - DETAIL" && data[i].screen !==
										"ITEM DETAIL - CONFIRM") {

										var oScrollContainer = new sap.m.ScrollContainer({
											vertical: true,
											focusable: true,
											content: [oSimpleFormx]

										}).addStyleClass("height");
										var pnl = new sap.m.Panel({
											id: "pnlTAB_" + data[i].UiPosition,
											title: new sap.ui.core.Title({
												text: ""
											}),
											content: oScrollContainer
										});

										var tabFilter = sap.ui.getCore().byId("STEP" + data[i].UiPosition);

										tabFilter.destroyContent();
										tabFilter.addContent(pnl);

									} else if (data[i].screen === "LIST") {
										console.log("entered list");
									} else if (data[i].screen === "LIST - DETAIL") {

										console.log("entered list detail");

									} else if (data[i].screen === "ITEM DETAIL - CONFIRM") {

										console.log("entered Item detail-confirm");

									} else {
										var vertical = new sap.ui.layout.VerticalLayout({
											/* title: new sap.ui.core.Title({
											     text: ""
											 }),*/
											content: oSimpleFormx
										}).addStyleClass("sapUiSmallMargin");

										var oScrollContainer = new sap.m.ScrollContainer({
											vertical: true,
											focusable: true,
											content: [oSimpleForm11]

										}).addStyleClass("height");

										var pnl = new sap.m.Panel({
											id: "pnlTAB_" + data[i].UiPosition,
											title: new sap.ui.core.Title({
												text: ""
											}),
											content: oScrollContainer
										});
										//	tabFilter.destroyContent();

										if (data[i].ItmId === "TAB83") {
											var pnl1 = that.BindHeaderData(data[i].UiPosition);
											//var x = sap.ui.getCore().headertemplate;
											//	tabFilter.addContent(pnl1);
										}

										tabFilter.destroyContent();
										tabFilter.addContent(pnl);

									}

								}

							}
							//	that.detailBindFooterButton(sap.ui.getCore().ctabitemid);
							i++;
							sap.ui.getCore().homeThis.addTabFilterAndContent(i, data, success);
						}
					});
				} else {
					i++;
					sap.ui.getCore().homeThis.addTabFilterAndContent(i, data, success);
				}

			} catch (e) {
				alert("addTabFilterContent Exception : " + e.message);
			}
		},

		/*	masterListBinding: function() {
				
					
					
					
		
					
					
			try {
				var list = this.getView().byId("Delv_LST");
				list.setBusy(true).setBusyIndicatorDelay(0);
			var itemTemplate = new sap.m.ObjectListItem({
					icon: "sap-icon://accept",
					title: "{ServiceOrderID}",
					type:"Navigation" ,
					
					
					attributes: [new sap.m.ObjectAttribute({
							text: "{CustomerName}"
						}),
						new sap.m.ObjectAttribute({
							text: "{Location}"
						}),
						new sap.m.ObjectAttribute({
							text: "{Partner}"
						})
					]
				});
			
						var jModel = new sap.ui.model.json.JSONModel();
						jModel.setData({
							itemData: sap.ui.getCore().ServiceOrderData
						});
						list.setModel(jModel);
						list.bindAggregation("items", "/itemData", itemTemplate);
							list.setBusy(false);
						//sap.ui.getCore().masterBack = true;
					}
	
				
				
			 catch (e) {
				alert("MasterListBinding Exception: " + e.message);
			}
		}*/

	});

});
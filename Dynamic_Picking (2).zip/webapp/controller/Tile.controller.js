sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("com.crave.DynamicPicking.controller.Tile", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.crave.inventory.view.Tile
		 */
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("Tile").attachPatternMatched(this.onRouteMatched, this);
		},
		onRouteMatched: function() {
			sap.ui.getCore().oMyCurrentView = "Tile";
			this.settingBinding();
		},
		settingBinding: function() {
			var that = this;
			var view = that.getView();
			//var oModel = view.getModel();
			var oModel = new sap.ui.model.odata.ODataModel("/WMS900/sap/opu/odata/CRVWM/RF_WM_30_SRV")
	//		/sap/opu/odata/CRVWM/RF_WM_30_SRV/DynMenuSet?$filter=Lgnum eq '001' and Mmenu eq 'MAIN'
			var configSetting = "/DynMenuSet?$filter=Lgnum eq '001' and Mmenu eq 'MAIN'";
			oModel.read(configSetting, null, null, true, function(oResponse) {
				sap.ui.getCore().getconfigSettingSet = oResponse;
			});
		},
/*tilebinding: function()
{
		var jModel = new sap.ui.model.json.JSONModel();
				jModel.setData({
					tileData: sap.ui.getCore().Tile.filter(function(item) {
						item.count = sap.ui.getCore().arr[i++];
						return item;
					})
				});

				var oTileContainer = view.byId("container");
				var oTileTemplate = new sap.m.StandardTile({
					title: "{TileDesc}",
					number: "{count}",
					icon: "sap-icon://{Icon}",
					press: view.getController().onPress
				}).addStyleClass("STD_TILE");
				oTileContainer.setModel(jModel);
				oTileContainer.bindAggregation("tiles", "/tileData", oTileTemplate);
},
*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.crave.inventory.view.Tile
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.crave.inventory.view.Tile
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.crave.inventory.view.Tile
		 */
		//	onExit: function() {
		//
		//	}
		OnInbound: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("InBound", {});
		},
		OnOutbound: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("OutBoundTile", {});
		},
		OnInternal: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("InternalTransfer", {});
		},

		OnList_2: function() {
			this.handleInfoMessageBoxPress(
				"Sorry you are using the demo version of application. To explore all feature please contact us at contact@craveinfotech.com ..");
		},
		onlogout: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("Login", {});
		},
		onLogin_setting: function() {

			sap.ui.core.UIComponent.getRouterFor(this).navTo("Login_Setting", {});
		},
		handleInfoMessageBoxPress: function(msg) {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.information(
				msg, {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		}

	});

});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller,JSONModel) {
	"use strict";

	return Controller.extend("com.crave.DynamicPicking.controller.Form", {

			onInit: function() {
							sap.ui.getCore().homeThis = this;
							var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZPR_SOIL_COUNT_SRV");
							//	var myInputField=this.getView().byId("input");
							//	sap.ui.getCore().x=myInputField;
						//myInputField._getValueHelpIcon().setSrc("sap-icon://bar-code");
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.oEvent = sap.ui.getCore().getEventBus();
			this.setData();
			this.createTimeline();

			
			},
			
			onRouteMatched: function(oEvent) {
					},
			setData: function()
			{
sap.ui.getCore().ServiceOrderData =[
	{
			"PoNumber": "4500001251",
			"JobTitle": "Vendor",
			"JobResponsibilities": "Plans, organizes and manages the operations and activities of an accounts payables.\nSupervises employees and monitors activities.\nFinal check of accounts payable payments and sign off.\nReporting to the head of finance.\n\n\"I am a diligent person. I put great attention to detail.\"",
			"HireDate": "Date(1371020400000)"
	},
		 
		 {	"PoNumber": "6789",
			"JobTitle": "4500001251",
			"JobResponsibilities": "Plans, organizes and manages the operations and activities of an accounts payables.\nSupervises employees and monitors activities.\nFinal check of accounts payable payments and sign off.\nReporting to the head of finance.\n\n\"I am a diligent person. I put great attention to detail.\"",
			"HireDate": "Date(1371020400000)"
		 }
		 ]; 
			},
				createTimeline:function()
			{
				
			/*	var oTimeline = new Timeline({
    enableDoubleSided: true
});
				var oItem = new TimelineItem({
	dateTime: "{HireDate}",
	title: "{PoNumber}",
    text: "{JobResponsibilities}",
    userName: "{JobTitle}"
});*/

//	this.getView().setModel(oModel);
//			this._timeline = this.byId("idTimeline");
var oTimeline=this.getView().byId("idTimeline");

var jModel = new sap.ui.model.json.JSONModel();
						jModel.setData({
							itemData: sap.ui.getCore().ServiceOrderData
						});
						oTimeline.setModel(jModel);
					/*	oTimeline.bindAggregation("content", {
    path: "/itemData",
    template: oItem
});*/
}
			
			
			

			
		
				
				
			
			
				 
	
   
     
      
			

	
	});

});